<div class="col-md-6">
    <?php $nama = Auth::user()->cuprimer->name; ?>
    <h2>Selamat Datang CU {{ $nama }}</h2>
    <p>Anda berada di halaman member cu {{ $nama }}</p>
</div>

