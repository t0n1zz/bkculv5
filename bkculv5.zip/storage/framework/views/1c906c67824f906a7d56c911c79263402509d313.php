<script>
    var randomColorFactor = function() {
        return Math.round(Math.random() * 255);
    };
    var randomColor = function(opacity) {
        return 'rgba(' + randomColorFactor() + ',' + randomColorFactor() + ',' + randomColorFactor() + ',' + (opacity || '.3') + ')';
    };
    var config = {
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
            type: 'bar',
        <?php else: ?>
            type: 'line',
        <?php endif; ?>
        data: data_l_biasa,
        options:{
            responsive: true,
            legend: {
                position: 'top'
            },
            title: {
                display: true,
                text: ''
            },
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true,
                        callback: function(value, index, values) {
                            if(parseInt(value) > 1000){
                                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                            } else {
                                return value;
                            }
                        }
                    }
                }]
            }
        }
    };
    <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
        var config2 = {
            type: 'bar',
            data: data_l_biasa2,
            options:{
                responsive: true,
                legend: {
                    position: 'top'
                },
                title: {
                    display: true,
                    text: ''
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:true,
                            callback: function(value, index, values) {
                                if(parseInt(value) > 1000){
                                    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                } else {
                                    return value;
                                }
                            }
                        }
                    }]
                }
            }
        };
        var config3 = {
            type: 'bar',
            data: data_l_biasa3,
            options:{
                responsive: true,
                legend: {
                    position: 'top'
                },
                title: {
                    display: true,
                    text: ''
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:true,
                            callback: function(value, index, values) {
                                if(parseInt(value) > 1000){
                                    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                } else {
                                    return value;
                                }
                            }
                        }
                    }]
                }
            }
        };
    <?php endif; ?>
    var config4 = {
        type: 'bar',
        data: data_p1,
        options:{
            responsive: true,
            legend: {
                position: 'top'
            },
            title: {
                display: true,
                text: ''
            },
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true,
                        callback: function(value, index, values) {
                            if(parseInt(value) > 1000){
                                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                            } else {
                                return value;
                            }
                        }
                    }
                }]
            }
        }
    };

    $.each(config.data.datasets, function(i, dataset) {
        dataset.borderColor = randomColor(0.4);
        dataset.backgroundColor = randomColor(0.5);
        dataset.pointBorderColor = randomColor(0.7);
        dataset.pointBackgroundColor = randomColor(0.5);
        dataset.pointBorderWidth = 1;
    });
    <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
            $.each(config2.data.datasets, function(i, dataset) {
            dataset.borderColor = randomColor(0.4);
            dataset.backgroundColor = randomColor(0.5);
            dataset.pointBorderColor = randomColor(0.7);
            dataset.pointBackgroundColor = randomColor(0.5);
            dataset.pointBorderWidth = 1;
        });
        $.each(config3.data.datasets, function(i, dataset) {
            dataset.borderColor = randomColor(0.4);
            dataset.backgroundColor = randomColor(0.5);
            dataset.pointBorderColor = randomColor(0.7);
            dataset.pointBackgroundColor = randomColor(0.5);
            dataset.pointBorderWidth = 1;
        });
    <?php endif; ?>
    $.each(config4.data.datasets, function(i, dataset) {
        dataset.borderColor = randomColor(0.4);
        dataset.backgroundColor = randomColor(0.5);
        dataset.pointBorderColor = randomColor(0.7);
        dataset.pointBackgroundColor = randomColor(0.5);
        dataset.pointBorderWidth = 1;
    });
    window.onload = function() {
        var ctx = document.getElementById("chart").getContext("2d");
        var ctx4 = document.getElementById("chart4").getContext("2d");
        window.chart = new Chart(ctx, config);
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
            var ctx2 = document.getElementById("chart2").getContext("2d");
            var ctx3 = document.getElementById("chart3").getContext("2d");
            window.chart2 = new Chart(ctx2, config2);
            window.chart3 = new Chart(ctx3, config3);
        <?php endif; ?>
        window.chart4 = new Chart(ctx4, config4);
    };
</script>