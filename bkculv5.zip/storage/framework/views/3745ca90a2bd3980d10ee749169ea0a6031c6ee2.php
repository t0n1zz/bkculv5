<script>
    var data_l_biasa = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Anggota Lelaki Biasa",
                data: <?php echo json_encode($gl_biasa,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_l_lbiasa = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Anggota Lelaki Luar Biasa",
                data: <?php echo json_encode($gl_lbiasa,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_p_biasa = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Anggota Perempuan Biasa",
                data: <?php echo json_encode($gp_biasa,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }

        ]
    };
    var data_p_lbiasa = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Anggota Perempuan Luar Biasa",
                data: <?php echo json_encode($gp_lbiasa,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_aset = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "aset (ASET)",
                data: <?php echo json_encode($gaset,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_aktivalancar = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Aktiva Lancar",
                data: <?php echo json_encode($gaktivalancar,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_simpanansaham = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Simpanan Saham",
                data: <?php echo json_encode($gsimpanansaham,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_nonsaham_unggulan = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Simpanan Non Saham Unggulan",
                data: <?php echo json_encode($gnonsaham_unggulan,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_nonsaham_harian = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Simpanan Non Saham Harian & Deposito",
                data: <?php echo json_encode($gnonsaham_harian,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_hutangspd = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Hutang SPD",
                data: <?php echo json_encode($ghutangspd,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_piutangberedar = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Piutang Beredar",
                data: <?php echo json_encode($gpiutangberedar,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_piutanglalai_1bulan = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Piutang Lalai 1-12 Bulan",
                data: <?php echo json_encode($gpiutanglalai_1bulan,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_piutanglalai_12bulan = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Piutang Lalai > 12 Bulan",
                data: <?php echo json_encode($gpiutanglalai_12bulan,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_dcr = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "DCR",
                data: <?php echo json_encode($gdcr,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_dcu = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "DCU",
                data: <?php echo json_encode($gdcu,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_totalpendapatan = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Total Pendapatan",
                data: <?php echo json_encode($gtotalpendapatan,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_totalbiaya = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Total Biaya",
                data: <?php echo json_encode($gtotalbiaya,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_shu = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "SHU",
                data: <?php echo json_encode($gshu,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_totalanggota = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Total Anggota",
                data: <?php echo json_encode($gtotalanggota,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_piutangbersih = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Piutang Bersih",
                data: <?php echo json_encode($gpiutangbersih,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_rasioberedar = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Rasio Piutang Beredar",
                data: <?php echo json_encode($grasioberedar,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_rasiolalai = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Rasio Piutang Lalai",
                data: <?php echo json_encode($grasiolalai,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_anggota = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "Anggota Lelaki Biasa",
                data: <?php echo json_encode($gl_biasa,JSON_NUMERIC_CHECK); ?>

            },
            {
                label: "Anggota Lelaki Luar Biasa",
                data: <?php echo json_encode($gl_lbiasa,JSON_NUMERIC_CHECK); ?>

            },
            {
                label: "Anggota Perempuan Biasa",
                data: <?php echo json_encode($gp_biasa,JSON_NUMERIC_CHECK); ?>

            },
            {
                label: "Anggota Perempuan Luar Biasa",
                data: <?php echo json_encode($gp_lbiasa,JSON_NUMERIC_CHECK); ?>

            }
        ]
    };
    <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
        var data_l_biasa2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Anggota Lelaki Biasa",
                    data: <?php echo json_encode($gl_biasa2,JSON_NUMERIC_CHECK); ?>

                }
            ]
        };
        var data_l_lbiasa2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Anggota Lelaki Luar Biasa",
                    data: <?php echo json_encode($gl_lbiasa2,JSON_NUMERIC_CHECK); ?>

                }
            ]
        };
        var data_p_biasa2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Anggota Perempuan Biasa",
                    data: <?php echo json_encode($gp_biasa2,JSON_NUMERIC_CHECK); ?>

                }

            ]
        };
        var data_p_lbiasa2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Anggota Perempuan Luar Biasa",
                    data: <?php echo json_encode($gp_lbiasa2,JSON_NUMERIC_CHECK); ?>

                }
            ]
        };
        var data_aset2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "aset (ASET)",
                    data: <?php echo json_encode($gaset2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_aktivalancar2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Aktiva Lancar",
                    data: <?php echo json_encode($gaktivalancar2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_simpanansaham2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Simpanan Saham",
                    data: <?php echo json_encode($gsimpanansaham2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_nonsaham_unggulan2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Simpanan Non Saham Unggulan",
                    data: <?php echo json_encode($gnonsaham_unggulan2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_nonsaham_harian2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Simpanan Non Saham Harian & Deposito",
                    data: <?php echo json_encode($gnonsaham_harian2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_hutangspd2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Hutang SPD",
                    data: <?php echo json_encode($ghutangspd2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_piutangberedar2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Piutang Beredar",
                    data: <?php echo json_encode($gpiutangberedar2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_piutanglalai_1bulan2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Piutang Lalai 1-12 Bulan",
                    data: <?php echo json_encode($gpiutanglalai_1bulan2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_piutanglalai_12bulan2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Piutang Lalai > 12 Bulan",
                    data: <?php echo json_encode($gpiutanglalai_12bulan2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_dcr2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "DCR",
                    data: <?php echo json_encode($gdcr2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_dcu2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "DCU",
                    data: <?php echo json_encode($gdcu2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_totalpendapatan2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Total Pendapatan",
                    data: <?php echo json_encode($gtotalpendapatan2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_totalbiaya2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Total Biaya",
                    data: <?php echo json_encode($gtotalbiaya2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_shu2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "SHU",
                    data: <?php echo json_encode($gshu2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_totalanggota2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Total Anggota",
                    data: <?php echo json_encode($gtotalanggota2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_piutangbersih2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Piutang Bersih",
                    data: <?php echo json_encode($gpiutangbersih2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_rasioberedar2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Rasio Piutang Beredar",
                    data: <?php echo json_encode($grasioberedar2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_rasiolalai2 = {
            labels: <?php echo json_encode($gperiode2,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Rasio Piutang Lalai",
                    data: <?php echo json_encode($grasiolalai2,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };

        var data_l_biasa3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Anggota Lelaki Biasa",
                    data: <?php echo json_encode($gl_biasa3,JSON_NUMERIC_CHECK); ?>

                }
            ]
        };
        var data_l_lbiasa3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Anggota Lelaki Luar Biasa",
                    data: <?php echo json_encode($gl_lbiasa3,JSON_NUMERIC_CHECK); ?>

                }
            ]
        };
        var data_p_biasa3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Anggota Perempuan Biasa",
                    data: <?php echo json_encode($gp_biasa3,JSON_NUMERIC_CHECK); ?>

                }

            ]
        };
        var data_p_lbiasa3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Anggota Perempuan Luar Biasa",
                    data: <?php echo json_encode($gp_lbiasa3,JSON_NUMERIC_CHECK); ?>

                }
            ]
        };
        var data_aset3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "aset (ASET)",
                    data: <?php echo json_encode($gaset3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_aktivalancar3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Aktiva Lancar",
                    data: <?php echo json_encode($gaktivalancar3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_simpanansaham3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Simpanan Saham",
                    data: <?php echo json_encode($gsimpanansaham3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_nonsaham_unggulan3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Simpanan Non Saham Unggulan",
                    data: <?php echo json_encode($gnonsaham_unggulan3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_nonsaham_harian3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Simpanan Non Saham Harian & Deposito",
                    data: <?php echo json_encode($gnonsaham_harian3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_hutangspd3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Hutang SPD",
                    data: <?php echo json_encode($ghutangspd3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_piutangberedar3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Piutang Beredar",
                    data: <?php echo json_encode($gpiutangberedar3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_piutanglalai_1bulan3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Piutang Lalai 1-12 Bulan",
                    data: <?php echo json_encode($gpiutanglalai_1bulan3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_piutanglalai_12bulan3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Piutang Lalai > 12 Bulan",
                    data: <?php echo json_encode($gpiutanglalai_12bulan3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_dcr3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "DCR",
                    data: <?php echo json_encode($gdcr3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_dcu3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "DCU",
                    data: <?php echo json_encode($gdcu3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_totalpendapatan3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Total Pendapatan",
                    data: <?php echo json_encode($gtotalpendapatan3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_totalbiaya3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Total Biaya",
                    data: <?php echo json_encode($gtotalbiaya3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_shu3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "SHU",
                    data: <?php echo json_encode($gshu3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_totalanggota3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Total Anggota",
                    data: <?php echo json_encode($gtotalanggota3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_piutangbersih3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Piutang Bersih",
                    data: <?php echo json_encode($gpiutangbersih3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_rasioberedar3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Rasio Piutang Beredar",
                    data: <?php echo json_encode($grasioberedar3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
        var data_rasiolalai3 = {
            labels: <?php echo json_encode($gperiode3,JSON_NUMERIC_CHECK); ?>,
            datasets: [
                {
                    label: "Rasio Piutang Lalai",
                    data: <?php echo json_encode($grasiolalai3,JSON_NUMERIC_CHECK); ?>,
                    fill: false
                }
            ]
        };
    <?php endif; ?>
    var data_p1 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "P1",
                data: <?php echo json_encode($gp1,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_p2 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "P2",
                data: <?php echo json_encode($gp2,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_e1 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "E1",
                data: <?php echo json_encode($ge1,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_e5 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "E5",
                data: <?php echo json_encode($ge5,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_e6 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "E6",
                data: <?php echo json_encode($ge6,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_e9 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "E9",
                data: <?php echo json_encode($ge9,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_a1 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "A1",
                data: <?php echo json_encode($ga1,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_a2 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "A2",
                data: <?php echo json_encode($ga2,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_r7 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "R7",
                data: <?php echo json_encode($gr7,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_r9 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "R9",
                data: <?php echo json_encode($gr9,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_l1 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "L1",
                data: <?php echo json_encode($gl1,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_s10 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "S10",
                data: <?php echo json_encode($gs10,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
    var data_s11 = {
        labels: <?php echo json_encode($gperiode,JSON_NUMERIC_CHECK); ?>,
        datasets: [
            {
                label: "S11",
                data: <?php echo json_encode($gs11,JSON_NUMERIC_CHECK); ?>,
                fill: false
            }
        ]
    };
</script>