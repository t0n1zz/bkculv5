<table class="table table-hover" id="dataTables-all" width="100%">
    <thead>
    <tr class="bg-light-blue-active color-palette">
        <th rowspan="2" width="5%">#</th>
        <th rowspan="2" hidden></th>
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?><th rowspan="2">Nama Credit Union</th><?php endif; ?>
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?><th rowspan="2">BA</th><?php endif; ?>
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?><th rowspan="2">District Office</th><?php endif; ?>
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?><th rowspan="2">Provinsi / Wilayah</th><?php endif; ?>
        <?php if(Request::is('admins/perkembangancu/index_cu/*')): ?><th rowspan="2">Data Per</th><?php endif; ?>
        <th colspan="5">Anggota</th>
        <th rowspan="2">Kekayaan (ASET)</th>
        <th rowspan="2">Aktiva LANCAR</th>
        <th rowspan="2">Simpanan Saham(SP+SW)</th>
        <th colspan="2">Simpanan Non Saham</th>
        <th rowspan="2">Hutang SPD</th>
        <th colspan="2">Piutang</th>
        <th colspan="2">Piutang Lalai</th>
        <th colspan="2">Rasio Piutang</th>
        <th rowspan="2">DCR</th>
        <th rowspan="2">DCU</th>
        <th colspan="2">Total</th>
        <th rowspan="2">SHU</th>
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?><th rowspan="2">Data Per</th><?php endif; ?>
    </tr>
    <tr class="bg-light-blue-active color-palette">
        <th>Lelaki Biasa</th>
        <th>Lelaki L.Biasa</th>
        <th>Perempuan Biasa</th>
        <th>Perempuan L.Biasa</th>
        <th>Total</th>
        <th>Unggulan</th>
        <th>Harian & Deposito</th>
        <th>Beredar</th>
        <th>Bersih</th>
        <th> 1-12 Bulan</th>
        <th> > 12 Bulan</th>
        <th>Beredar</th>
        <th>Lalai</th>
        <th>Pendapatan</th>
        <th>Biaya</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $tot_l_biasa = 0;
    $tot_l_lbiasa = 0;
    $tot_p_biasa = 0;
    $tot_p_lbiasa = 0;
    $tot_anggota = 0;
    $tot_kekayaan = 0;
    $tot_aktivalancar = 0;
    $tot_simpanansaham = 0;
    $tot_nonsaham_unggulan = 0;
    $tot_nonsaham_harian = 0;
    $tot_hutangspd = 0;
    $tot_piutangberedar = 0;
    $tot_piutanglalai_1bulan = 0;
    $tot_piutanglalai_12bulan = 0;
    $tot_piutangbersih = 0;
    $tot_dcr = 0;
    $tot_dcu = 0;
    $tot_totalpendapatan = 0;
    $tot_totalbiaya = 0;
    $tot_shu = 0;
    ?>
    <?php foreach($datas as $data): ?>
        <tr
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
            <?php if($data->dataper < $datas->first()->dataper): ?><?php echo 'class="highlight"'; ?><?php endif; ?>
                <?php endif; ?>>
            <td></td>
            <td hidden><?php echo e($data->id); ?></td>
            <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
                <?php if(!empty($data->cuprimer)): ?><td><?php echo e($data->cuprimer->name); ?></td><?php else: ?><td>-</td><?php endif; ?>
            <?php endif; ?>

            <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
                <?php if(!empty($data->cuprimer)): ?><td><?php echo e($data->cuprimer->no_ba); ?></td><?php else: ?><td>-</td><?php endif; ?>
            <?php endif; ?>

            <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
                <?php
                if($data->cuprimer->do == "1"){
                    $do ="Barat";
                }else if($data->cuprimer->do == "2"){
                    $do ="Tengah";
                }else if($data->cuprimer->do == "3"){
                    $do ="Timur";
                }
                ?>
                <?php if(!empty($data->cuprimer)): ?><td><?php echo e($do); ?></td><?php else: ?><td>-</td><?php endif; ?>
            <?php endif; ?>

            <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
                <?php
                foreach($wilayahcuprimers as $wilayahcuprimer){
                    if($data->cuprimer->wilayah == $wilayahcuprimer->id){
                        $wilayah =$wilayahcuprimer->name;
                    }
                }
                ?>
                <?php if(!empty($data->cuprimer)): ?><td><?php echo e($wilayah); ?></td><?php else: ?><td>-</td><?php endif; ?>
            <?php endif; ?>

            <?php if(Request::is('admins/perkembangancu/index_cu/*')): ?>
                <?php if(!empty($data->dataper)): ?>
                    <?php $date = new Date($data->dataper); ?>
                    <td data-order="<?php echo e($data->dataper); ?>"> <?php echo e($date->format('F Y')); ?></td>
                <?php else: ?>
                    <td>0</td>
                <?php endif; ?>
            <?php endif; ?>  

            <?php if(!empty($data->l_biasa)): ?>
                <?php $l_biasa = number_format($data->l_biasa,"0",",","."); $tot_l_biasa += $data->l_biasa;?>
                <td data-order="<?php echo e($data->l_biasa); ?>"><?php echo e($l_biasa); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->l_lbiasa)): ?>
                <?php $l_lbiasa = number_format($data->l_lbiasa,"0",",",".");  $tot_l_lbiasa += $data->l_lbiasa;?>
                <td data-order="<?php echo e($data->l_lbiasa); ?>"><?php echo e($l_lbiasa); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->p_biasa)): ?>
                <?php $p_biasa = number_format($data->p_biasa,"0",",","."); $tot_p_biasa += $data->p_biasa;?>
                <td data-order="<?php echo e($data->p_biasa); ?>"><?php echo e($p_biasa); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->p_lbiasa)): ?>
                <?php $p_lbiasa = number_format($data->p_lbiasa,"0",",","."); $tot_p_lbiasa += $data->p_lbiasa;?>
                <td data-order="<?php echo e($data->p_lbiasa); ?>"><?php echo e($p_lbiasa); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->l_biasa) || !empty($data->l_lbiasa) || !empty($data->p_biasa) ||!empty($data->p_lbiasa)): ?>
                <?php
                $total = $data->l_biasa + $data->l_lbiasa + $data->p_biasa + $data->p_lbiasa;
                $total_num = number_format($total,"0",",",".");
                $tot_anggota += $total;
                ?>
                <td data-order="<?php echo e($total); ?>"><?php echo e($total_num); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->kekayaan)): ?>
                <?php $kekayaan = number_format($data->kekayaan,"0",",","."); $tot_kekayaan += $data->kekayaan;?>
                <td data-order="<?php echo e($data->kekayaan); ?>"><?php echo e($kekayaan); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->aktivalancar)): ?>
                <?php $aktivalancar = number_format($data->aktivalancar,"0",",","."); $tot_aktivalancar += $data->aktivalancar;?>
                <td data-order="<?php echo e($data->aktivalancar); ?>"><?php echo e($aktivalancar); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->simpanansaham)): ?>
                <?php $simpanansaham = number_format($data->simpanansaham,"0",",","."); $tot_simpanansaham += $data->simpanansaham;?>
                <td data-order="<?php echo e($data->simpanansaham); ?>"><?php echo e($simpanansaham); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->nonsaham_unggulan)): ?>
                <?php $nonsaham_unggulan = number_format($data->nonsaham_unggulan,"0",",","."); $tot_nonsaham_unggulan += $data->nonsaham_unggulan;?>
                <td data-order="<?php echo e($data->nonsaham_unggulan); ?>"><?php echo e($nonsaham_unggulan); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->nonsaham_harian)): ?>
                <?php $nonsaham_harian = number_format($data->nonsaham_harian,"0",",","."); $tot_nonsaham_harian += $data->nonsaham_harian;?>
                <td data-order="<?php echo e($data->nonsaham_harian); ?>"><?php echo e($nonsaham_harian); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->hutangspd)): ?>
                <?php $hutangspd = number_format($data->hutangspd,"0",",","."); $tot_hutangspd += $data->hutangspd;?>
                <td data-order="<?php echo e($data->hutangspd); ?>"><?php echo e($hutangspd); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->piutangberedar)): ?>
                <?php $piutangberedar = number_format($data->piutangberedar,"0",",","."); $tot_piutangberedar += $data->piutangberedar;?>
                <td data-order="<?php echo e($data->piutangberedar); ?>"><?php echo e($piutangberedar); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->piutanglalai_1bulan)): ?>
                <?php $piutanglalai_1bulan = number_format($data->piutanglalai_1bulan,"0",",","."); $tot_piutanglalai_1bulan += $data->piutanglalai_1bulan;?>
                <td data-order="<?php echo e($data->piutanglalai_1bulan); ?>"><?php echo e($piutanglalai_1bulan); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->piutanglalai_12bulan)): ?>
                <?php $piutanglalai_12bulan = number_format($data->piutanglalai_12bulan,"0",",","."); $tot_piutanglalai_12bulan += $data->piutanglalai_12bulan;?>
                <td data-order="<?php echo e($data->piutanglalai_12bulan); ?>"><?php echo e($piutanglalai_12bulan); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->piutangberedar) || !empty($data->piutanglalai_1bulan) || !empty($data->piutanglalai_12bulan)): ?>
                <?php
                $piutangbersih = $data->piutangberedar - ($data->piutanglalai_1bulan + $data->piutanglalai_12bulan);
                $piutangbersih_num = number_format($piutangbersih,"0",",",".");
                $tot_piutangbersih += $piutangbersih;
                ?>
                <td data-order="<?php echo e($piutangbersih); ?>"><?php echo e($piutangbersih_num); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->kekayaan) || !empty($data->piutangberedar)): ?>
                <?php $rasio_beredar = number_format((($data->piutangberedar / $data->kekayaan)*100),2); ?>
                <td data-order="<?php echo e($rasio_beredar); ?>"><?php echo e($rasio_beredar); ?> %</td>
            <?php else: ?>
                <td>0 %</td>
            <?php endif; ?>

            <?php if(!empty($data->piutangberedar) || !empty($data->piutanglalai_1bulan) || !empty($data->piutanglalai_12bulan)): ?>
                <?php $rasio_lalai = number_format(((($data->piutanglalai_1bulan + $data->piutanglalai_12bulan) / $data->piutangberedar)*100),2); ?>
                <td data-order="<?php echo e($rasio_lalai); ?>"><?php echo e($rasio_lalai); ?> %</td>
            <?php else: ?>
                <td>0 %</td>
            <?php endif; ?>

            <?php if(!empty($data->dcr)): ?>
                <?php $dcr = number_format($data->dcr,"0",",","."); $tot_dcr += $data->dcr;?>
                <td data-order="<?php echo e($data->dcr); ?>"><?php echo e($dcr); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->dcu)): ?>
                <?php $dcu = number_format($data->dcu,"0",",","."); $tot_dcu += $data->dcu;?>
                <td data-order="<?php echo e($data->dcu); ?>"><?php echo e($dcu); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->totalpendapatan)): ?>
                <?php $totalpendapatan = number_format($data->totalpendapatan,"0",",","."); $tot_totalpendapatan += $data->totalpendapatan;?>
                <td data-order="<?php echo e($data->totalpendapatan); ?>"><?php echo e($totalpendapatan); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->totalbiaya)): ?>
                <?php $totalbiaya = number_format($data->totalbiaya,"0",",","."); $tot_totalbiaya += $data->totalbiaya;?>
                <td data-order="<?php echo e($data->totalbiaya); ?>"><?php echo e($totalbiaya); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!empty($data->shu)): ?>
                <?php $shu = number_format($data->shu,"0",",","."); $tot_shu += $data->shu;?>
                <td data-order="<?php echo e($data->shu); ?>"><?php echo e($shu); ?></td>
            <?php else: ?>
                <td>0</td>
            <?php endif; ?>

            <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?>
                <?php if(!empty($data->dataper)): ?>
                    <?php $date = new Date($data->dataper); ?>
                    <td data-order="<?php echo e($data->dataper); ?>"> <?php echo e($date->format('F Y')); ?></td>
                <?php else: ?>
                    <td>0</td>
                <?php endif; ?>
            <?php endif; ?>    
        </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
    <tr class="bg-lime-active color-palette">
        <th>TOTAL</th>
        <th hidden></th>
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?><th></th><?php endif; ?>
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?><th></th><?php endif; ?>
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?><th></th><?php endif; ?>
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?><th></th><?php endif; ?>
        <?php if(Request::is('admins/perkembangancu/index_cu/*')): ?><th></th><?php endif; ?>
        <th><?php echo e(number_format($tot_l_biasa,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_l_lbiasa,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_p_biasa,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_p_lbiasa,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_anggota,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_kekayaan,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_aktivalancar,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_simpanansaham,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_nonsaham_unggulan,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_nonsaham_harian,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_hutangspd,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_piutangberedar,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_piutanglalai_1bulan,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_piutanglalai_12bulan,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_piutangbersih,"0",",",".")); ?></th>
        <th>-</th>
        <th>-</th>
        <th><?php echo e(number_format($tot_dcr,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_dcu,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_totalpendapatan,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_totalbiaya,"0",",",".")); ?></th>
        <th><?php echo e(number_format($tot_shu,"0",",",".")); ?></th>
        <?php if(!Request::is('admins/perkembangancu/index_cu/*')): ?><th></th><?php endif; ?>
    </tr>
    </tfoot>
</table>