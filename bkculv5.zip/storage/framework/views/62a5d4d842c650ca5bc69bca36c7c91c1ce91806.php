<?php
$currentpage = $_SERVER['REQUEST_URI'];
?>
<div class="hidden-header"></div>
<header class="clearfix">
    <?php /*top bar*/ ?>
    <div class="top-bar dark-bar">
        <div class="marquee" style="padding: 5px 10px;border-bottom: 1px solid white;color: white;">
            <?php $i = 0; ?>
            <?php foreach($pengumumans as $pengumuman): ?>
                <?php if($i == 0): ?> <?php echo '<i class="fa fa-fw fa-circle"></i>'; ?><?php endif; ?>
                <b><?php echo $pengumuman->name; ?></b>
                <?php $i++; ?>
                <?php if($i < $pengumumans->count()): ?> <?php echo '<i class="fa fa-fw fa-circle"></i>'; ?><?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
    <?php /*top bar*/ ?>

    <?php /*logo & navigation*/ ?>
    <div class="navbar navbar-default navbar-top">
        <div class="container">
            <div class="navbar-header">
                <?php /*mobile menu*/ ?>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <i class="fa fa-bars"></i>
                </button>
                <?php /*mobile menu*/ ?>
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    <div class="hidden-xs">
                        <img alt="" src="<?php echo e(asset('images/logo3.png')); ?>">
                    </div>
                    <div class="visible-xs-inline">
                        <img alt="" src="<?php echo e(asset('images/logo4.png')); ?>">
                    </div>
                </a>
            </div>
            <div class="navbar-collapse collapse">
                <?php /*search*/ ?>
                <?php /*<div class="search-side">*/ ?>
                    <?php /*<a class="show-search"><i class="fa fa-search"></i></a>*/ ?>
                    <?php /*<div class="search-form">*/ ?>
                        <?php /*<form autocomplete="off" role="search" method="get" class="searchform" action="#">*/ ?>
                            <?php /*<input type="text" value="" name="s" id="s" placeholder="Search the site...">*/ ?>
                        <?php /*</form>*/ ?>
                    <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>
                <?php /*search*/ ?>
                <?php if(\Request::is('cu/*') || \Request::is('cu')): ?>
                <?php /*cu*/ ?>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?php echo e(route('home')); ?>" <?php if($currentpage == "/"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Home</a></li>
                    <li><a href="<?php echo e(route('cu')); ?>" <?php if($currentpage == "/cu"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Dashboard</a></li>
                    <li><a href="<?php echo e(route('cu.kelola_kegiatan')); ?>" <?php if($currentpage == "/cu/kelola_kegiatan"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>DIKLAT</a></li>
                    <li>
                        <a href="#"
                        <?php if($currentpage == "/cu/edit_info" || $currentpage == "/cu/edit_deskripsi"): ?>
                            <?php echo e('class="active"'); ?>

                                <?php endif; ?>>CU</a>
                        <ul class="dropdown">
                            <li><a href="<?php echo e(route('cu.edit_deskripsi')); ?>" <?php if($currentpage == "/cu/edit_deskripsi"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>
                                        >Profil</a></li>
                            <li><a href="<?php echo e(route('cu.edit_info')); ?>" <?php if($currentpage == "/cu/edit_info"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>
                                        >Informasi Umum</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"
                        <?php if($currentpage == "/cu/kelola_staf"): ?>
                            <?php echo e('class="active"'); ?>

                                <?php endif; ?>>Staf</a>
                        <ul class="dropdown">
                            <li><a href="<?php echo e(route('cu.create_staf')); ?>" <?php if($currentpage == "/cu/create_staf"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>
                                        >Tambah Staf</a></li>
                            <li><a href="<?php echo e(route('cu.kelola_staf')); ?>" <?php if($currentpage == "/cu/kelola_staf"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>
                                        >Kelola Staf</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(route('cu.logout')); ?>">Logout</a></li>
                </ul>
                <?php /*cu*/ ?>
                <?php else: ?>
                <?php /*public*/ ?>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?php echo e(route('home')); ?>" <?php if($currentpage == "/"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Home</a></li>
                    <li><a href="<?php echo e(route('kegiatan')); ?>" <?php if($currentpage == "/kegiatan"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Kegiatan</a></li>
                    <li>
                        <a href="#"
                        <?php if($currentpage == "/artikel/0" || $currentpage == "/artikel/2" || $currentpage == "/artikel/5" ||
                            $currentpage == "/artikel/6" || $currentpage == "/artikel/7" || $currentpage == "/artikel/9"): ?>
                            <?php echo e('class="active"'); ?>

                        <?php endif; ?>>Berita </a>
                        <ul class="dropdown">
                            <li><a href="<?php echo e(route('artikel',array(0))); ?>" <?php if($currentpage == "/artikel/0"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>
                                        >Semua Berita</a></li>
                            <?php foreach($navberita as $berita): ?>
                                <li><a href="<?php echo e(route('artikel',array($berita->id))); ?>" <?php if($currentpage == "/artikel/$berita->id"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>
                                            ><?php echo e($berita->name); ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                    <li>
                        <a href="#"
                        <?php if($currentpage == "/profil" || $currentpage == "/pengurus" || $currentpage == "/pengawas" ||
                            $currentpage == "/manajemen" || $currentpage == "/pelayanan" || $currentpage == "/cuprimer" ||
                            $currentpage == "/artikel/4" || $currentpage == "/artikel/8"): ?>
                            <?php echo e('class="active"'); ?>

                        <?php endif; ?>>Tentang Kami </a>
                        <ul class="dropdown">
                            <li><a href="<?php echo e(route('profil')); ?>" <?php if($currentpage == "/profil"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Profil</a></li>
                            <li><a href="<?php echo e(route('pengurus')); ?>" <?php if($currentpage == "/pengurus"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Pengurus</a></li>
                            <li><a href="<?php echo e(route('pengawas')); ?>" <?php if($currentpage == "/pengawas"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Pengawas</a></li>
                            <li><a href="<?php echo e(route('manajemen')); ?>" <?php if($currentpage == "/manajemen"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Manajemen</a></li>
                            <li><a href="<?php echo e(route('pelayanan')); ?>" <?php if($currentpage == "/pelayanan"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Pelayanan</a></li>
                            <li><a href="<?php echo e(route('cuprimer')); ?>" <?php if($currentpage == "/cuprimer"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Credit Union</a></li>
                            <li><a href="<?php echo e(route('artikel',array(4))); ?>" <?php if($currentpage == "/artikel/4"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Filosofi</a></li>
                            <li><a href="<?php echo e(route('artikel',array(8))); ?>" <?php if($currentpage == "/artikel/8"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Sejarah</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"
                        <?php if($currentpage == "/download" || $currentpage == "/hymnecu"): ?>
                            <?php echo e('class="active"'); ?>

                        <?php endif; ?>>Lain-lain </a>
                        <ul class="dropdown">
                            <li><a href="<?php echo e(route('download')); ?>" <?php if($currentpage == "/download"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Download</a></li>
                            <li><a href="https://www.flickr.com/photos/127271987@N07/" target="_BLANK">Foto Kegiatan</a></li>
                            <li><a href="<?php echo e(route('hymnecu')); ?>" <?php if($currentpage == "/hymnecu"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Hymne CU</a></li>
                        </ul>
                    </li>
                    <!-- <li><a href="<?php echo e(route('cu.login')); ?>" <?php if($currentpage == "/cu/login"): ?> <?php echo e('class="active"'); ?> <?php endif; ?>>Login</a></li> -->
                </ul>
                <?php /*public*/ ?>
                <?php endif; ?>
            </div>
        </div>

        <?php /*mobile menu*/ ?>
        <ul class="wpb-mobile-menu">
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('kegiatan')); ?>">Kegiatan</a></li>
            <li>
                <a href="#">Berita </a>
                <ul class="dropdown">
                    <li><a href="<?php echo e(route('artikel',array(0))); ?>">Semua Berita</a></li>
                    <?php foreach($navberita as $berita): ?>
                        <li><a href="<?php echo e(route('artikel',array($berita->id))); ?>"><?php echo e($berita->name); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </li>
            <li>
                <a href="#" >Tentang Kami </a>
                <ul class="dropdown">
                    <li><a href="<?php echo e(route('profil')); ?>">Profil</a></li>
                    <li><a href="<?php echo e(route('pengurus')); ?>">Pengurus</a></li>
                    <li><a href="<?php echo e(route('pengawas')); ?>">Pengawas</a></li>
                    <li><a href="<?php echo e(route('manajemen')); ?>">Manajemen</a></li>
                    <li><a href="<?php echo e(route('pelayanan')); ?>">Pelayanan</a></li>
                    <li><a href="<?php echo e(route('cuprimer')); ?>">CU Primer</a></li>
                    <li><a href="<?php echo e(route('artikel',array(4))); ?>">Filosofi</a></li>
                    <li><a href="<?php echo e(route('artikel',array(8))); ?>">Sejarah</a></li>
                </ul>
            </li>
            <li>
                <a href="#" >Lain-lain </a>
                <ul class="dropdown">
                    <li><a href="<?php echo e(route('download')); ?>">Download</a></li>
                    <li><a href="https://www.flickr.com/photos/127271987@N07/" target="_BLANK">Foto Kegiatan</a></li>
                    <li><a href="<?php echo e(route('hymnecu')); ?>">Hymne CU</a></li>
                </ul>
            </li>
            <!-- <li><a href="<?php echo e(route('cu.login')); ?>">Login</a> </li> -->
        </ul>
    </div>

</header>


