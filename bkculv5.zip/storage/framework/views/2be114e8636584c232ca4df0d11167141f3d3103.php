<?php
$title = "Kelola Kegiatan";
$kelas = "kegiatan";
?>


<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('admins._components.datatable_CSS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- header -->
<section class="content-header">
    <h1>
        <i class="fa fa-suitcase"></i> <?php echo e($title); ?>

        <small>Mengelola Data Kegiatan</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><i class="fa fa-suitcase"></i> <?php echo e($title); ?></li>
    </ol>
</section>
<!-- /header -->
<section class="content">
    <!-- Alert -->
    <?php echo $__env->make('admins._layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /Alert -->
    <!--content-->
    <div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#tab_kegiatan" data-toggle="tab">Kegiatan</a></li>
        </ul>
        <div class="tab-content"> 
            <div class="tab-pane active" id="tab_kegiatan">
                <?php if(Auth::user()->getCU() == '0'): ?>
                    <div class="col-sm-8" style="padding: .2em ;">
                <?php else: ?>
                    <div class="col-sm-12" style="padding: .2em ;">
                <?php endif; ?>
                    <div class="input-group tabletools">
                        <div class="input-group-addon"><i class="fa fa-search"></i></div>
                        <input type="text" id="searchtext" class="form-control" placeholder="Kata kunci pencarian..." autofocus>
                    </div>
                </div>
                <?php if(Auth::user()->getCU() == '0'): ?>
                <div class="col-sm-3" style="padding: .2em ;">
                    <?php
                        $data = App\Models\Kegiatan::orderBy('tanggal','DESC')->groupBy('tanggal')->get(['tanggal']);
                        $dataperiode = $data->groupBy('tanggal');

                        $dataperiode1 = collect([]);
                        foreach ($dataperiode as $data){
                            $dataperiode1->push($data->first());
                        }
                        $periodes = array_column($dataperiode1->toArray(),'tanggal');
                    ?>
                    <div class="input-group tabletools">
                        <div class="input-group-addon primary-color"><i class="fa fa-clock-o fa-fw"></i> Periode Kegiatan</div>
                        <select class="form-control"  id="">
                            <?php foreach($periodes as $periode): ?>
                                <?php $date = new Date($periode); ?>
                                <option value=""><?php echo e($date->format('Y')); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <?php endif; ?>
                <table class="table table-hover" id="dataTables-example" width="100%">
                    <thead class="bg-light-blue-active color-palette">
                    <tr>
                        <th data-sortable="false">#</th>
                        <th hidden></th>
                        <th>Nama </th>
                        <th>Wilayah</th>
                        <th>Tempat</th>
                        <th>Sasaran</th>
                        <th>Mulai</th>
                        <th>Selesai</th>
                        <th>Lama</th>
                        <th>Terlaksana</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($datas as $data): ?>
                        <tr>
                            <td class="bg-aqua disabled color-palette"></td>
                            <td hidden><?php echo e($data->id); ?></td>
                            <?php if(!empty($data->name)): ?>
                                <td class="warptext"><?php echo e($data->name); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>

                            <?php if(!empty($data->wilayah)): ?>
                                <td><?php echo e($data->wilayah); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>

                            <?php if(!empty($data->tempat)): ?>
                                <td><?php echo e($data->tempat); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>

                            <?php if(!empty($data->sasaran)): ?>
                                <td class="warptext"><?php echo e($data->sasaran); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>

                            <?php if(!empty($data->tanggal)): ?>
                                <?php $date = new Date($data->tanggal); ?>
                                <td><i hidden="true"><?php echo e($data->tanggal); ?></i> <?php echo e($date->format('d/n/Y')); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>

                            <?php if(!empty($data->tanggal2)): ?>
                                <?php $date2 = new Date($data->tanggal2); ?>
                                <td><i hidden="true"><?php echo e($data->tanggal2); ?></i> <?php echo e($date2->format('d/n/Y')); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>

                            <td>
                                <?php
                                    $startTimeStamp = strtotime($data->tanggal);
                                    $endTimeStamp = strtotime($data->tanggal2);
                                    $timeDiff = abs($endTimeStamp - $startTimeStamp);
                                    $numberDays = $timeDiff/86400;
                                    $numberDays = intval($numberDays);
                                ?>
                                <?php echo e($numberDays); ?> Hari
                            </td>

                            <?php if($data->status == "0"): ?>
                                <td>Belum</td>
                            <?php else: ?>
                                <td>Sudah</td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--content-->
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('admins._components.datatable_JS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="text/javascript" src="<?php echo e(URL::asset('admin/datatable.js')); ?>"></script>
    <script>
        new $.fn.dataTable.Buttons(table,{
            buttons: [
                <?php if (Auth::check() && Auth::user()->can('create.'.$kelas.'_create')): ?>
                {
                    text: '<i class="fa fa-plus"></i> <u>T</u>ambah',
                    key: {
                        altKey: true,
                        key: 't'
                    },
                    action: function(){
                        window.location.href = "<?php echo e(URL::to('admins/'.$kelas.'/create')); ?>";
                    }
                },
                <?php endif; ?>
                <?php if (Auth::check() && Auth::user()->can('update.'.$kelas.'_update')): ?>
                {
                    text: '<i class="fa fa-pencil"></i> <u>U</u>bah',
                    key: {
                        altKey: true,
                        key: 'u'
                    },
                    action: function(){
                        var id = $.map(table.rows({ selected: true }).data(),function(item){
                            return item[1];
                        });
                        var kelas = "<?php echo e($kelas); ?>";
                        if(id != ""){
                            window.location.href =  kelas + "/" + id + "/edit";
                        }else{
                            $('#modalwarning').modal({show:true});
                        }
                    }
                },
                <?php endif; ?>
                <?php if (Auth::check() && Auth::user()->can('destroy.'.$kelas.'_destroy')): ?>
                {
                    text: '<i class="fa fa-trash"></i> <u>H</u>apus',
                    key: {
                        altKey: true,
                        key: 'h'
                    },
                    action: function(){
                        var id = $.map(table.rows({ selected:true }).data(),function(item){
                            return item[1];
                        });
                        var name = $.map(table.rows({ selected:true }).data(),function(item){
                            return item[2];
                        });
                        if(id != ""){
                            $('#modalhapus').modal({show:true});
                            $('#modalhapus_id').attr('value',id);
                            $('#modalhapus_judul').text('Hapus Kegiatan');
                            $('#modalhapus_detail').text('Yakin menghapus kegiatan "' + name + '" ?');
                        }else{
                            $('#modalwarning').modal({show:true});
                        }
                    }
                }
                <?php endif; ?>
            ]
        });
        table.buttons( 0, null ).container().prependTo(
                table.table().container()
        );

        new $.fn.dataTable.Buttons(table,{
            buttons: [
                <?php if (Auth::check() && Auth::user()->can('view.kegaitandetail_view')): ?>
                {
                    text: '<i class="fa fa-database"></i> Detail',
                    action: function(){
                        var id = $.map(table.rows({ selected: true }).data(),function(item){
                            return item[1];
                        });
                        var kelas = "<?php echo e($kelas); ?>";
                        if(id != ""){
                            window.location.href =  kelas + "/" + id + "/detail";
                        }else{
                            $('#modalwarning').modal({show:true});
                        }
                    }
                }
                <?php endif; ?>
            ]
        });
        table.buttons( 0, null ).container().prependTo(
                table.table().container()
        );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>