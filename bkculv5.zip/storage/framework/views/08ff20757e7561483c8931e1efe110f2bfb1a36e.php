<?php
$title="Kelola Staf";
$imagepath = "images_staf/";
?>


<?php $__env->startSection('css'); ?>
        <!-- DataTables CSS -->
<?php echo e(Html::style('plugins/dataTables/bootstrap/dataTables.bootstrap.css')); ?>

<?php echo e(Html::style('plugins/dataTables/extension/Responsive/css/dataTables.responsive.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!-- Page Title -->
<div class="page-banner" style="padding:40px 0; background: url(images/slide-02-bg.jpg) center #f9f9f9;">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>DIKLAT</h2>
                <p>Anda dapat mendaftarkan staf anda pada DIKLAT yang kami sediakan</p>
            </div>
            <div class="col-md-6">
                <ul class="breadcrumbs">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li>CU</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div id="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('cu.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th></th>
                                <th data-priority="1">Nama </th>
                                <th>Wilayah</th>
                                <th>Tempat</th>
                                <th>Sasaran</th>
                                <th>Tanggal Dimulai</th>
                                <th>Tanggal Selesai</th>
                                <th data-priority="2">Daftar</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($datas as $data): ?>
                                <tr>
                                    <td></td>
                                    <?php if(!empty($data->name)): ?>
                                        <td><b><?php echo e($data->name); ?></b></td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>

                                    <?php if(!empty($data->wilayah)): ?>
                                        <td><?php echo e($data->wilayah); ?></td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>

                                    <?php if(!empty($data->tempat)): ?>
                                        <td><?php echo e($data->tempat); ?></td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>

                                    <?php if(!empty($data->sasaran)): ?>
                                        <td><?php echo e($data->sasaran); ?></td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>

                                    <?php if(!empty($data->tanggal)): ?>
                                        <?php $date = new Date($data->tanggal); ?>
                                        <td><i hidden="true"><?php echo e($data->tanggal); ?></i> <?php echo e($date->format('d/n/Y')); ?></td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>

                                    <?php if(!empty($data->tanggal2)): ?>
                                        <?php $date2 = new Date($data->tanggal2); ?>
                                        <td><i hidden="true"><?php echo e($data->tanggal2); ?></i> <?php echo e($date2->format('d/n/Y')); ?></td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>

                                    <?php if($data->status == "0"): ?>
                                        <td><a href="#" class="btn btn-default" disabled>
                                                <i hidden="true">tidak</i><i class="fa fa-ban"></i></a></td>
                                    <?php else: ?>
                                        <td><a href="<?php echo e(route('cu.daftar_kegiatan',array($data->id))); ?>" class="btn btn-warning">
                                                <i hidden="true">iya</i><i class="fa fa-plus"></i></a></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Hapus -->
<div class="modal fade" id="modal1show" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <?php echo e(Form::model($datas, array('route' => array('cu.destroy_staf'), 'method' => 'delete'))); ?>

    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-trash"></i> Hapus Staf</h4>
            </div>
            <div class="modal-body">
                <strong style="font-size: 16px">Menghapus staf ini?</strong>
                <input type="text" name="id" value="" id="modal1id" hidden>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-warning" id="modalbutton"><i class="fa fa-check"></i> Iya</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Batal</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
    <?php echo e(Form::close()); ?>

</div>
<!-- /Hapus -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<!-- DataTables JavaScript -->
<?php echo e(Html::script('plugins/dataTables/jquery.dataTables.js')); ?>

<?php echo e(Html::script('plugins/dataTables/bootstrap/dataTables.bootstrap.js')); ?>

<?php echo e(Html::script('plugins/dataTables/extension/Responsive/js/dataTables.responsive.js')); ?>

<script>
    $(document).ready(function() {
        var table = $('#dataTables-example').dataTable({
            responsive: {
                details: {
                    type: 'column'
                }
            },
            columnDefs: [ {
                className: 'control',
                orderable: false,
                targets:   0
            } ],
            pagingType : "full_numbers",
            autoWidth: false,
            stateSave : true,
            order : [[ 0, "asc" ]]
        });

        $('.modal1').on('click',function(){
            $('#modal1show').modal({
                show: true,
            })

            var myvalue = this.name;
            var myvalue2 = this.title;
            $('#modal1id').attr('value',myvalue);
            $('#modal1id2').attr('value',myvalue2);
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>