<?php 
    $title="Pemberitahuan";
    $user = Auth::user();
 ?>


<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('admins._components.datatable_CSS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- header -->
<section class="content-header">
    <h1>
        <i class="fa fa-bell-o"></i> <?php echo e($title); ?>

        <small>Semua Pemberitahuan</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><i class="fa fa-bell-o"></i> <?php echo e($title); ?></li>
    </ol>
</section>
<!-- /header -->
<section class="content">
    <!-- Alert -->
    <?php echo $__env->make('admins._layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /Alert -->
    <div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#tab_pemberitahuan" data-toggle="tab">Pemberitahuan</a></li>
        </ul>
        <div class="tab-content"> 
            <div class="tab-pane active" id="tab_pemberitahuan" style="a:color:black;">
                <?php if(!empty($user->notifications) && count($user->notifications) > 0 ): ?>
                        <?php $__currentLoopData = $user->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $notification): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php 
                                if ($i > 25) break;
                                $username = App\User::where('id',$notification->data['user'])->select('name')->first(); 
                            ?>
                            <?php if(strtolower($notification->data['tipe']) == 'menambah laporancu'): ?>
                                <a href="<?php echo e(route('admins.laporancu.detail',array($notification->data['url']))); ?>" style="white-space: normal;color: black;">
                                <i class="fa fa-line-chart text-aqua"></i><b class="text-aqua">
                            <?php elseif(strtolower($notification->data['tipe']) == 'mengubah laporancu'): ?>  
                                <a href="<?php echo e(route('admins.laporancu.detail',array($notification->data['url']))); ?>" style="white-space: normal;color: black;">
                                <i class="fa fa-line-chart text-warning"></i><b class="text-warning">
                            <?php elseif(strtolower($notification->data['tipe']) == 'menghapus laporancu'): ?>  
                                <a href="<?php echo e(route('admins.laporancu.detail',array($notification->data['url']))); ?>" style="white-space: normal;color: black;">
                                <i class="fa fa-line-chart text-danger"></i><b class="text-danger">     
                            <?php elseif(strtolower($notification->data['tipe']) == 'menulis diskusilaporan'): ?> 
                                <a href="<?php echo e(route('admins.laporancu.detail',array($notification->data['url']))); ?>" style="white-space: normal;color: black;">
                                <i class="fa fa-commenting-o text-aqua"></i><b class="text-aqua">
                            <?php elseif(strtolower($notification->data['tipe']) == 'mengubah diskusilaporan'): ?> 
                                <a href="<?php echo e(route('admins.laporancu.detail',array($notification->data['url']))); ?>" style="white-space: normal;color: black;">
                                <i class="fa fa-commenting-o text-warning"></i><b class="text-warning">
                            <?php elseif(strtolower($notification->data['tipe']) == 'menghapus diskusilaporan'): ?> 
                                <a href="<?php echo e(route('admins.laporancu.detail',array($notification->data['url']))); ?>" style="white-space: normal;color: black;">
                                <i class="fa fa-commenting-o text-danger"></i><b class="text-danger">        
                            <?php endif; ?>
                            <?php echo e($username->name); ?> [<?php echo e($notification->data['cu']); ?>]</b> 
                            <?php $date = new Date($notification->created_at); ?>
                            <?php echo e($notification->data['message']); ?><br/>

                            <?php if(!empty($notification->data['message2'])): ?>
                                <div class="well well-sm" style="margin-bottom: 0px;color: black;"><?php echo e($notification->data['message2']); ?></div>
                            <?php endif; ?>

                            <small class="text-muted"><?php echo e($date->format('d F')); ?> - <?php echo e($date->format('H:i')); ?></small> 
                            </a>
                            <hr style="margin-top: 5px;" />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <?php else: ?>
                    Kamu memiliki tidak memiliki pemberitahuan.
                    <hr/>
                <?php endif; ?>    
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('admins._components.datatable_JS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="text/javascript" src="<?php echo e(URL::asset('admin/datatable.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>