<?php
$title = "Kelola Staf";

if(!empty($datas->first()->cuprimer))
    $title2 ="CU " . $datas->first()->cuprimer->name;
else
    $title2 ="Puskopdit BKCU Kalimantan";


$kelas = "staf";
$imagepath = "images_staf/";
?>


<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('admins._components.datatable_CSS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- header -->
    <section class="content-header">
        <h1>
            <i class="fa fa-sitemap"></i> <?php echo e($title); ?>

            <small>Mengelola Data Staf <?php echo $title2; ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active"><i class="fa fa-sitemap"></i> <?php echo $title; ?></li>
        </ol>
    </section>
    <!-- /header -->
    <!-- /header -->
    <section class="content">
        <!-- Alert -->
    <?php echo $__env->make('admins._layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /Alert -->
        <!--content-->
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
                <li class="active"><a href="#tab_staf" data-toggle="tab">Staf</a></li>
            </ul>
            <div class="tab-content"> 
                <div class="tab-pane active" id="tab_staf">
                    <?php if(Auth::user()->getCU() == '0'): ?>
                        <div class="col-sm-8" style="padding: .2em ;">
                    <?php else: ?>
                        <div class="col-sm-12" style="padding: .2em ;">
                    <?php endif; ?>
                        <div class="input-group tabletools">
                            <div class="input-group-addon"><i class="fa fa-search"></i></div>
                            <input type="text" id="searchtext" class="form-control" placeholder="Kata kunci pencarian..." autofocus>
                        </div>
                    </div>
                    <?php if(Auth::user()->getCU() == '0'): ?>
                        <div class="col-sm-4" style="padding: .2em ;">
                            <?php $culists = App\Models\Cuprimer::orderBy('name','asc')->get(); ?>
                            <div class="input-group tabletools">
                                <div class="input-group-addon primary-color"><i class="fa fa-users"></i> Staf CU</div>
                                <select class="form-control"  id="dynamic_select">
                                    <option <?php echo e(Request::is('admins/staf/') ? 'selected' : ''); ?>

                                            value="/admins/staf/"><b>PUSKOPDIT BKCU Kalimantan</b></option>
                                    <?php foreach($culists as $culist): ?>
                                        <option <?php echo e(Request::is('admins/staf/index_cu/'.$culist->no_ba) ? 'selected' : ''); ?>

                                                value="/admins/staf/index_cu/<?php echo e($culist->no_ba); ?>"><b><?php echo e($culist->name); ?></b></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    <?php endif; ?>
                    <table class="table table-hover" id="dataTables-example"  width="100%">
                        <thead class="bg-light-blue-active color-palette">
                            <tr>
                                <th data-sortable="false">#</th>
                                <th hidden></th>
                                <th data-sortable="false">Foto</th>
                                <th>Nama </th>
                                <th>Jenis Kelamin</th>
                                <th>Jabatan</th>
                                <th>Status</th>
                                <th>Agama</th>
                                <th>Pendidikan</th>
                                <th>No. Telepon</th>
                                <th>No. Handphone</th>
                                <th>E-mail</th>
                                <th>Alamat</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($datas as $data): ?>
                            <?php
                                $newarr = explode("\n",$data->alamat);
                                foreach($newarr as $str){
                                    $alamat = $str;
                                }

                                $jabatans = \App\Models\StafRiwayat::where('id_staf','=',$data->id)
                                                ->where('tipe','=',3)->get();
                                
                                $pekerjaan = array();
                                $i = 0;
                                foreach ($jabatans as $j){
                                    if($i < 1){
                                        if($j->keterangan == $id){
                                            if($j->keterangan2 == 'Manajemen'){
                                                if($j->sekarang == "1"){
                                                    $pekerjaan[] = $j->name;
                                                    $i++;
                                                }
                                            }else{
                                                $mulai = \Carbon\Carbon::createFromFormat('Y-m-d', $j->mulai)->format('Y');
                                                $selesai = \Carbon\Carbon::createFromFormat('Y-m-d', $j->selesai)->format('Y');
                                                $now =   \Carbon\Carbon::now()->format('Y');
                                                if($selesai >= $now){
                                                    $pekerjaan[] = $j->name.' periode '.$mulai.' - '.$selesai;
                                                    $i++;
                                                }
                                            }
                                        }
                                    }
                                }
                            ?>
                            <tr >
                                <td class="bg-aqua disabled color-palette"></td>    
                                <td hidden><?php echo e($data->id); ?></td>
                                <?php if(!empty($data->gambar) && is_file($imagepath.$data->gambar."n.jpg")): ?>
                                    <td style="white-space: nowrap"><div class="modalphotos" >
                                            <?php echo e(Html::image($imagepath.$data->gambar.'n.jpg',asset($imagepath.$data->gambar."jpg"),
                                             array('class' => 'img-responsive',
                                            'id' => 'tampilgambar', 'width' => '40px'))); ?>

                                        </div></td>
                                <?php elseif(!empty($data->gambar) && is_file($imagepath.$data->gambar)): ?>
                                    <td style="white-space: nowrap"><div class="modalphotos" >
                                            <?php echo e(Html::image($imagepath.$data->gambar,asset($imagepath.$data->gambar),
                                                array('class' => 'img-responsive ',
                                                'id' => 'tampilgambar', 'width' => '40px'))); ?>

                                        </div></td>
                                <?php else: ?>
                                    <?php if($data->kelamin == "Wanita"): ?>
                                        <td><?php echo e(Html::image('images/no_image_woman.jpg', 'a picture', array('class' => 'img-responsive',
                                                            'id' => 'tampilgambar', 'width' => '40px'))); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e(Html::image('images/no_image_man.jpg', 'a picture', array('class' => 'img-responsive',
                                                            'id' => 'tampilgambar', 'width' => '40px'))); ?></td>
                                    <?php endif; ?>
                                <?php endif; ?>
                                
                                <td><?php echo e($data->name); ?></td>
                                <td><?php echo e($data->kelamin); ?></td>
                                <td>
                                <?php foreach($pekerjaan as $p): ?>
                                    <?php echo e($p); ?><br/>
                                <?php endforeach; ?>
                                </td>
                                <td><?php echo e($data->status); ?></td>
                                <td><?php echo e($data->agama); ?></td>
                                <td><?php echo e($data->pendidikan); ?></td>
                                <td><?php echo e($data->telp); ?></td>
                                <td><?php echo e($data->handphone); ?></td>
                                <td><?php echo e($data->email); ?></td>
                                <td><?php echo e($alamat); ?></td>
                            </tr>
                        <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>
            </div>    
        </div>
    </section>
    <!-- modal -->
    <!-- Hapus -->
    <div class="modal fade" id="modal1show" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <?php echo e(Form::model($datas, array('route' => array('admins.'.$kelas.'.destroy',$kelas), 'method' => 'delete'))); ?>

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-trash"></i> Hapus Staf</h4>
                </div>
                <div class="modal-body">
                    <h4>Menghapus staf ini ?</h4>
                    <input type="text" name="id" value="" id="modal1id" hidden>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-warning" id="modalbutton"><i class="fa fa-check"></i> Iya</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Batal</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
        <?php echo e(Form::close()); ?>

    </div>
    <!-- /Hapus -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('admins._components.datatable_JS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="text/javascript" src="<?php echo e(URL::asset('admin/datatable.js')); ?>"></script>
    <script>
        function format ( dataSource ) {
            var html = '<table class="table table-bordered" cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
            for (var key in dataSource){
                html += '<tr>'+
                        '<td>' + key             +'</td>'+
                        '<td>' + dataSource[key] +'</td>'+
                        '</tr>';
            }
            return html += '</table>';
        }


        new $.fn.dataTable.Buttons(table,{
            buttons: [
                <?php if (Auth::check() && Auth::user()->can('create.'.$kelas.'_create')): ?>
                {
                    text: '<i class="fa fa-plus"></i> <u>T</u>ambah',
                    key: {
                        altKey: true,
                        key: 't'
                    },
                    action: function(){
                        window.location.href = "<?php echo e(URL::to('admins/'.$kelas.'/create')); ?>";
                    }
                },
                <?php endif; ?>
                <?php if (Auth::check() && Auth::user()->can('update.'.$kelas.'_update')): ?>
                {
                    text: '<i class="fa fa-pencil"></i> <u>U</u>bah',
                    key: {
                        altKey: true,
                        key: 'u'
                    },
                    action: function(){
                        var id = $.map(table.rows({ selected: true }).data(),function(item){
                            return item[1];
                        });
                        var kelas = "<?php echo e($kelas); ?>";
                        if(id != ""){
                            window.location.href = "/admins/" + kelas + "/" + id + "/edit";
                        }else{
                            $('#modalwarning').modal({show:true});
                        }

                    }
                },
                <?php endif; ?>
                <?php if (Auth::check() && Auth::user()->can('destroy.'.$kelas.'_destroy')): ?>
                {
                    text: '<i class="fa fa-trash"></i> <u>H</u>apus',
                    key: {
                        altKey: true,
                        key: 'h'
                    },
                    action: function(){
                        var id = $.map(table.rows({ selected:true }).data(),function(item){
                            return item[1];
                        });
                        if(id != ""){
                            $('#modalhapus').modal({show:true});
                                $('#modalhapus_id').attr('value',id);
                                $('#modalhapus_judul').text('Hapus Staf');
                                $('#modalhapus_detail').text('Yakin menghapus staf ini ?');
                        }else{
                            $('#modalwarning').modal({show:true});
                        }
                    }
                }
                <?php endif; ?>
            ]
        });
        table.buttons( 0, null ).container().prependTo(
                table.table().container()
        );
        new $.fn.dataTable.Buttons(table,{
            buttons: [
                <?php if (Auth::check() && Auth::user()->can('view.stafdetail_view')): ?>
                {
                    text: '<i class="fa fa-database"></i> Detail',
                    action: function(){
                        var id = $.map(table.rows({ selected: true }).data(),function(item){
                            return item[1];
                        });
                        var kelas = "<?php echo e($kelas); ?>";
                        if(id != ""){
                            window.location.href = "/admins/" + kelas + "/" + id + "/detail";
                        }else{
                            $('#modalwarning').modal({show:true});
                        }

                    }
                }
                <?php endif; ?>
            ]
        });
        table.buttons( 0, null ).container().prependTo(
                table.table().container()
        );

        $(function(){
            // bind change event to select
            $('#dynamic_select').on('change', function () {
                var url = $(this).val(); // get selected value
                if (url) { // require a URL
                    window.location.href = url; // redirect
                }
                return false;
            });

            // $('#dataTables-example').on('click', 'td.details-control', function () {
            //     var tr = $(this).closest('tr');
            //     var row = table.row(tr);

            //     if (row.child.isShown()) {
            //         // This row is already open - close it
            //         row.child.hide();
            //         tr.removeClass('shown');
            //     } else {
            //         // Open this row
            //         row.child(format({
            //             'No. Telepon ' : tr.data('key-telp'),
            //             'No. Handphone' :  tr.data('key-handphone'),
            //             'Email' : tr.data('key-email'),
            //             'Kota' : tr.data('key-kota'),
            //             'Alamat' : tr.data('key-alamat')
            //         })).show();
            //         tr.addClass('shown');
            //     }
            // });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>