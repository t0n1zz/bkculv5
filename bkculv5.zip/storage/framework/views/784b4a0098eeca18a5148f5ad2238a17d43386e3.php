<?php
$imagepath ='images_cu/';
$kelas ='cuprimer';
$file_max = ini_get('upload_max_filesize');
$file_max_str_leng = strlen($file_max);
$file_max_meassure_unit = substr($file_max,$file_max_str_leng - 1,1);
$file_max_meassure_unit = $file_max_meassure_unit == 'K' ? 'kb' : ($file_max_meassure_unit == 'M' ? 'mb' : ($file_max_meassure_unit == 'G' ? 'gb' : 'unidades'));
$file_max = substr($file_max,0,$file_max_str_leng - 1);
$file_max = intval($file_max);
$cu = Auth::user()->getCU();
?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/summernote/summernote.css')); ?>" >
<?php $__env->stopSection(); ?>
<!-- Alert -->
<?php echo $__env->make('admins._layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /Alert -->
<!-- content -->
<div class="box box-primary">
    <div class="box-body">
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <h4>Foto CU</h4>
                    <div class="thumbnail" >
                        <?php if(!empty($data->gambar)): ?>
                            <?php echo e(Html::image($imagepath.$data->gambar.'n.jpg', 'a picture', array('class' => 'img-responsive', 'id' => 'tampilgambar', 'width' => '200'))); ?>

                        <?php else: ?>
                            <?php echo e(Html::image('images/no_image.jpg', 'a picture', array('class' => 'img-responsive', 'id' => 'tampilgambar', 'width' => '200'))); ?>

                        <?php endif; ?>
                        <div class="caption">
                            <?php echo e(Form::file('gambar', array('onChange' => 'readURL(this)'))); ?>

                        </div>
                    </div>
                    <div class="help-block">Ukuran maksimum file gambar adalah <?php echo $file_max. ' ' .$file_max_meassure_unit; ?>.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group has-feedback">
                    <h4>Nama</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                        <?php echo e(Form::text('name',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan nama cu',
                            'required','min-length' => '5','autocomplete'=>'off'))); ?>

                        <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                    </div>
                    <div class="help-block">Nama CU harus diisi dan minimal 5 karakter.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group has-feedback">
                    <h4>No. BA</h4>
                    <div class="input-group">
                        <span class="input-group-addon">0-9</span>
                        <?php if($cu == 0): ?>
                            <?php echo e(Form::number('no_ba',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan nomor anggota',
                                'onKeyPress' => 'return isNumberKey(event)','required','autocomplete'=>'off'))); ?>

                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                        <?php else: ?>
                            <?php echo e(Form::number('no_ba',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan nomor anggota','readonly'))); ?>

                        <?php endif; ?>    
                        
                    </div>
                    <div class="help-block">No. BA harus diisi.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <h4>Wilayah</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-list"></i></span>
                        <select class="form-control" onChange="changeFunc(value);" name="wilayah" required>
                            <option hidden>Silahkan pilih Wilayah</option>
                            <?php foreach($datas2 as $data2): ?>
                                <option value="<?php echo e($data2->id); ?>"
                                <?php if(!empty($data->wilayah)): ?>
                                    <?php if($data->wilayah == $data2->id): ?>
                                        <?php echo "selected"; ?>

                                            <?php endif; ?>
                                        <?php endif; ?>
                                ><?php echo e($data2->name); ?></option>
                            <?php endforeach; ?>
                            
                            <?php if (Auth::check() && Auth::user()->can('create.wilayahcuprimer_create')): ?>
                                <option disabled>--------------</option> 
                                <option value="tambah">Tambah Wilayah Baru</option>
                            <?php endif; ?> 
                        </select>
                    </div>
                    <div class="help-block">Wilayah harus dipilih.</div>
                </div>
            </div>
            <?php if (Auth::check() && Auth::user()->can('create.wilayahcuprimer_create')): ?>
            <div class="row" id="pilihan" style="display:none;">
                <div class="col-sm-12" >
                    <div class="form-group">
                        <h4>Wilayah Baru</h4>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-font"></i></span>
                            <?php echo e(Form::text('wilayah_baru',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan wilayah baru',
                                'autocomplete'=>'off'))); ?>

                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?> 
            <div class="col-sm-6">
                <div class="form-group">
                    <h4>No. Badan Hukum</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                        <?php echo e(Form::text('badan_hukum',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan nomor badan hukum',
                            'autocomplete'=>'off'))); ?>

                    </div>
                    <div class="help-block">Silahkan masukkan nomor badan hukum.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <h4>No. Telepon</h4>
                    <div class="input-group">
                        <span class="input-group-addon">0-9</span>
                        <?php echo e(Form::number('telp',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan nomor telepon','autocomplete'=>'off'))); ?>

                    </div>
                    <div class="help-block">Silahkan masukkan nomor telepon.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <h4>No. Handphone</h4>
                    <div class="input-group">
                        <span class="input-group-addon">0-9</span>
                        <?php echo e(Form::number('hp',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan nomor handphone','autocomplete'=>'off'))); ?>

                    </div>
                    <div class="help-block">Silahkan masukkan nomor handphone.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <h4>Kode Pos</h4>
                    <div class="input-group">
                        <span class="input-group-addon">0-9</span>
                        <?php echo e(Form::number('pos',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan kode pos'))); ?>

                    </div>
                    <div class="help-block">Silahkan masukkan kode pos.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <h4>Tanggal Berdiri</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        <?php
                        if(!empty($data->ultah)){
                            $timestamp = strtotime($data->ultah);
                            $tanggal = date('d/m/Y',$timestamp);
                        }
                        ?>
                        <input type="text" name="ultah" value="<?php if(!empty($tanggal)): ?><?php echo e($tanggal); ?><?php endif; ?>" class="form-control"
                               data-inputmask="'alias': 'date'" placeholder="dd/mm/yyyy" />
                    </div>
                    <div class="help-block">Tanggal berdiri CU harud diisi.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <h4>Tanggal Bergabung</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        <?php
                        if(!empty($data->bergabung)){
                            $timestamp = strtotime($data->bergabung);
                            $tanggal = date('d/m/Y',$timestamp);
                        }
                        ?>
                        <input type="text" name="bergabung" value="<?php if(!empty($tanggal)): ?><?php echo e($tanggal); ?><?php endif; ?>" class="form-control"
                               data-inputmask="'alias': 'date'" placeholder="dd/mm/yyyy" />
                    </div>
                    <div class="help-block">Tanggal bergabung CU harud diisi.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <h4>Website</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                        <?php echo e(Form::text('website',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan alamat website'))); ?>

                    </div>
                    <div class="help-block">Silahkan masukkan alamat website.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group has-feedback">
                    <h4>E-mail</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                        <?php echo e(Form::email('email',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan alamat email','autocomplete'=>'off'))); ?>

                        <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                    </div>
                    <div class="help-block">Silahkan masukkan alamat email.</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <h4>Aplikasi Komputerisasi</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                        <?php echo e(Form::text('app',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan nama aplikasi komputerisasi keuangan',
                            'autocomplete'=>'off'))); ?>

                    </div>
                    <div class="help-block">Silahkan masukkan nama aplikasi komputerisasi keuangan.</div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="form-group">
                    <h4>Alamat Kantor Pusat</h4>
                    <?php echo e(Form::textarea('alamat',null,array('class' => 'form-control','rows' => '3','placeholder'=>'Silahkan masukkan alamat'))); ?>

                    <div class="help-block">Silahkan masukkan alamat.</div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="form-group">
                    <h4>Deskripsi <small>Silahkan tambahkan misi, visi, nilai-nilai inti dan slogan serta profil singkat CU.</small></h4>
                    <?php echo e(Form::textarea('deskripsi',null,array('class' => 'form-control','rows' => '3','placeholder'=>'Silahkan masukkan alamat','id'=>'summernote'))); ?>

                    <div class="help-block">Silahkan masukkan alamat.</div>
                </div>
            </div>
        </div>
    </div>
    <div class="box-footer with-border">
            <button type="submit" name="simpan" accesskey="s" class="btn btn-primary" value="simpan">
                <i class="fa fa-save"></i> <u>S</u>impan</button>
            <?php if($cu == '0'): ?>      
                <button type="submit" name="simpan2" accesskey="m" class="btn btn-primary" value="simpan">
                    <i class="fa fa-save fa-fw"></i><i class="fa fa-plus"></i> Si<u>m</u>pan dan buat baru</button>
                <a href="<?php echo e(route('admins.'.$kelas.'.index')); ?>" name="batal" accesskey="b" class="btn btn-danger" value="batal">
                    <i class="fa fa-times"></i> <u>B</u>atal</a>
            <?php else: ?>
                <a href="<?php echo e(route('admins.'.$kelas.'.detail',array($cu))); ?>" name="batal" accesskey="b" class="btn btn-danger" value="batal">
                    <i class="fa fa-times"></i> <u>B</u>atal</a>   
            <?php endif; ?>     
            
    </div>
</div>


<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="<?php echo e(URL::asset('plugins/summernote/summernote.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('plugins/summernote/plugins/summernote-ext-addclass.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('plugins/summernote/plugins/summernote-cleaner.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#summernote').summernote({
            minHeight: 300,
            dialogsFade: true,
            placeholder: 'Silahkan isi disini...',
            addclass: {
                debug: false,
                classTags: [{title:"Button",value:"btn btn-success"},"jumbotron", "lead","img-rounded","img-circle", "img-responsive","btn", "btn btn-success","btn btn-danger","text-muted", "text-primary", "text-warning", "text-danger", "text-success", "table-bordered", "table-responsive", "alert", "alert alert-success", "alert alert-info", "alert alert-warning", "alert alert-danger", "visible-sm", "hidden-xs", "hidden-md", "hidden-lg", "hidden-print"]
            },
            cleaner:{
                notTime:2400, // Time to display Notifications.
                action:'paste', // both|button|paste 'button' only cleans via toolbar button, 'paste' only clean when pasting content, both does both options.
                newline:'<br>', // Summernote's default is to use '<p><br></p>'
                notStyle:'position:absolute;bottom:0;left:2px', // Position of Notification
                icon:'<i class="note-icon">Clean Word Format</i>'
            },
            toolbar: [
                ['cleaner',['cleaner']],
                ['para',['style']],
                ['style', ['addclass','bold', 'italic', 'underline', 'hr']],
                ['font', ['strikethrough', 'superscript', 'subscript','clear']],
                ['fontsize', ['fontsize']],
                ['color', ['color']],
                ['para', ['ul', 'ol']],
                ['paragraph',['paragraph']],
                ['table',['table']],
                ['height', ['height']],
                ['misc',['fullscreen','codeview']],
                ['misc2',['undo','redo']]
            ]
        });
    });    
</script>
<?php $__env->stopSection(); ?>