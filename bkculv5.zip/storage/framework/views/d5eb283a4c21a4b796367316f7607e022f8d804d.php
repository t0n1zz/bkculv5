<?php
$title = "Admin";
$kelas = "admin";
$imagepath = "images_user/";

$file_max = ini_get('upload_max_filesize');
$file_max_str_leng = strlen($file_max);
$file_max_meassure_unit = substr($file_max,$file_max_str_leng - 1,1);
$file_max_meassure_unit = $file_max_meassure_unit == 'K' ? 'kb' : ($file_max_meassure_unit == 'M' ? 'mb' : ($file_max_meassure_unit == 'G' ? 'gb' : 'unidades'));
$file_max = substr($file_max,0,$file_max_str_leng - 1);
$file_max = intval($file_max);

$datelogin = new Date($data->login);
$datelogout= new Date($data->logout);
?>


<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('admins._components.datatable_CSS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/summernote/summernote.css')); ?>" >
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <i class="fa fa-user-circle-o"></i> <?php echo e($title); ?>

        <small>Informasi <?php echo e($title); ?> </small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <?php if($cu == 0): ?>
            <li><a href="<?php echo e(route('admins.admin.index')); ?>"><i class="fa fa-user-circle-o"></i> Kelola Admin</li></a>
        <?php endif; ?>    
        <li class="active"><i class="fa fa-user-circle-o"></i> <?php echo e($title); ?></li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-3">
            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-body box-profile">
                    <?php if(!empty($data->gambar) && is_file($imagepath.$data->gambar.".jpg")): ?>
                        <div class="modalphotos" >
                            <img class="profile-user-img img-responsive img-circle"  width="100%" src="<?php echo e(asset($imagepath.$data->gambar.'.jpg')); ?>"
                                  alt="<?php echo e(asset($imagepath.$data->gambar."jpg")); ?>">
                        </div>
                    <?php else: ?>
                        <img class="profile-user-img img-responsive img-circle" width="100%"" src="<?php echo e(asset('images_user/user.jpg')); ?>">
                    <?php endif; ?>
                    <br/>
                    <h3 class="profile-username text-center"><?php echo e($data->name); ?></h3>
                    <?php if(!empty($data->cuprimer)): ?>
                        <p class="text-muted text-center"><?php echo e($data->cuprimer->name); ?></p>
                    <?php else: ?>
                        <p class="text-muted text-center">PUSKOPDIT BKCU Kalimantan</p>
                    <?php endif; ?>    
                    <ul class="list-group list-group-unbordered">
                        <li class="list-group-item">
                            <b>Username</b> <a class="pull-right"><?php echo e($data->username); ?></a>
                        </li>
                        <li class="list-group-item">
                            <b>Terakhir Login</b> <a class="pull-right"><?php echo e($datelogin->format('d/n/Y | H:i:s')); ?></a>
                        </li>
                        <li class="list-group-item">
                            <b>Terakhir Logout</b> <a class="pull-right"><?php echo e($datelogout->format('d/n/Y | H:i:s')); ?></a>
                        </li>
                    </ul>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>

        <div class="col-md-9">
            <!-- Alert -->
            <?php echo $__env->make('admins._layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /Alert -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#password" data-toggle="tab">Ubah Password</a></li>
                    <li ><a href="#foto" data-toggle="tab">Ubah Foto</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="password">
                        <?php echo e(Form::open(array('route' => array('admins.'.$kelas.'.update_password'),'data-toggle'=>'validator','role'=>'form'))); ?>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group has-feedback">
                                    <h5>Password Saat Ini</h5>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                                        <?php echo e(Form::password('password_now',array('class' => 'form-control','id' =>'password_now', 'placeholder' => 'Silahkan masukkan password yang saat ini digunakan','required','data-minlength'=>'5'))); ?>

                                        <span class="glyphicon form-control-feedback"></span>
                                    </div>
                                </div>
                                <hr/>
                                <div class="form-group has-feedback">
                                    <h5>Password Baru</h5>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                                        <?php echo e(Form::password('password',array('class' => 'form-control','id' => 'password1', 'placeholder' => 'Silahkan masukkan password baru','required','data-minlength'=>'5'))); ?>

                                        <span class="glyphicon form-control-feedback"></span>       
                                    </div>
                                    <div class="help-block">Password minimal 5 karakter.</div>
                                </div>
                                <div class="form-group has-feedback">
                                    <h5>Ulangi Password</h5>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                                        <?php echo e(Form::password('password2',array('class' => 'form-control','id'=>'konfirmpassword',
                                           'placeholder' => 'Silahkan masukkan password admin sekali lagi','required',
                                           'data-match'=>'#password1','data-match-error'=>'Maaf, password tidak sesuai.'))); ?>

                                        <span class="glyphicon form-control-feedback"></span>       
                                    </div>
                                    <div class="help-block">Silahkan tulis ulang password anda.</div>
                                </div>
                                <hr/>
                                <button type="submit" class="btn btn-primary" id="modalbutton"><i class="fa fa-save"></i> Simpan</button>
                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div><!-- /.tab-pane -->
                    <div class="tab-pane" id="foto">
                        <?php echo e(Form::open(array('route' => array('admins.'.$kelas.'.update_gambar'), 'files' => true,'data-toggle'=>'validator','role'=>'form'))); ?>

                        <div class="row">
                            <div class="col-sm-12">
                                <input type="text" value="<?php echo e($data->id); ?>" name="id" hidden>
                                <input type="text" value="<?php echo e($data->name); ?>" name="name" hidden>
                                <div>
                                    <h5>Foto</h5>
                                    <div class="thumbnail" >
                                        <?php if(!empty($data->gambar) && is_file($imagepath.$data->gambar.".jpg")): ?>
                                            <?php echo e(Html::image($imagepath.$data->gambar.'.jpg', 'a picture', array('class' => 'img-responsive', 'id' => 'tampilgambar', 'width' => '200'))); ?>

                                        <?php else: ?>
                                            <?php echo e(Html::image('images_user/user.jpg', 'a picture', array('class' => 'img-responsive', 'id' => 'tampilgambar', 'width' => '200'))); ?>

                                        <?php endif; ?>
                                        <div class="caption">
                                            <?php echo e(Form::file('gambar', array('onChange' => 'readURL(this)','required'))); ?>

                                        </div>
                                    </div>
                                    <div class="help-block">Ukuran maksimum file gambar adalah <?php echo $file_max. ' ' .$file_max_meassure_unit; ?>.</div>
                                </div>
                               <hr/>
                               <button type="submit" class="btn btn-primary" id="modalbutton"><i class="fa fa-save"></i> Simpan</button> 
                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div><!-- /.tab-content -->
            </div><!-- /.nav-tabs-custom -->
        </div><!-- /.col -->
    </div><!-- /.row -->

</section><!-- /.content -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>