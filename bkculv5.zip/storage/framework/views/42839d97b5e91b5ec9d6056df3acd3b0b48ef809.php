<?php
$title = "Detail Laporan CU ";
$kelas = "laporancu";
$kelas2 = "laporancudiskusi";
$imagepath = 'images_user/';
$iduser = \Auth::user()->getId();
$culists = App\Cuprimer::orderBy('name','asc')->where('status','=','1')->get();
$culists_non = App\Cuprimer::orderBy('name','asc')->where('status','=','0')->get();

$dataperiode = App\laporancu::where('no_ba','=',$data->cuprimer->no_ba)->orderBy('periode','DESC')->get(['id','periode']);
$pilihperiode = $dataperiode->groupBy('periode');

$pilihperiodes = collect([]);
foreach ($pilihperiode as $dataperiode){
    $pilihperiodes->push($dataperiode->first());
}
?>


<?php $__env->startSection('content'); ?>
<!-- header -->
<section class="content-header">
    <h1>
        <i class="fa fa-database"></i> <?php echo e($title); ?>

        <small>CU <?php echo e($data->cuprimer->name); ?> </small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(URL::to('admins/laporancu/index_cu/'.$data->cuprimer->no_ba)); ?>"><i class="fa fa-line-chart"></i> Laporan CU <?php echo e($data->cuprimer->name); ?></a></li>
        <li class="active"><i class="fa fa-database"></i> <?php echo e($title); ?></li>
    </ol>
</section>
<!-- /header -->
<section class="content">
    <!-- Alert -->
    <?php echo $__env->make('admins._layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /Alert -->
    <!--content-->
    <div class="box box-solid">
        <div class="box-body">
            <div class="col-sm-12" style="padding: .2em ;">
                <div class="input-group">
                    <div class="input-group-addon primary-color"><i class="fa fa-clock-o fa-fw"></i> Periode Laporan</div>
                    <select class="form-control" id="dynamic_select2">
                        <?php $__currentLoopData = $pilihperiodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihperiode): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php $date = new Date($pilihperiode->periode); ?>
                            <option <?php echo e(Request::is('admins/laporancu/detail/'.$pilihperiode->id) ? 'selected' : ''); ?>

                                    value="/admins/laporancu/detail/<?php echo e($pilihperiode->id); ?>"><?php echo e($date->format('F Y')); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admins._components.laporancu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#tab_diskusi" data-toggle="tab">Diskusi
                <?php if(!empty($datas2) && count($datas2) > 0 ): ?>
                    <small><span class="label label-primary"><?php echo e(count($datas2 )); ?></span></small>
                <?php endif; ?>
            </a></li>
            <li><a href="#tab_revisi" data-toggle="tab">Revisi
                <?php if(!empty($datahistories) && count($datahistories) > 0 ): ?>
                    <small><span class="label label-primary" ><?php echo e(count($datahistories )); ?></span></small>
                <?php endif; ?>
            </a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane active" id="tab_diskusi">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="chat" id="chat-box"
                            <?php if($datas2->count() <= 3): ?>
                                style="padding-right: 5px;" 
                            <?php endif; ?>
                        >
                            <?php $__currentLoopData = $datas2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="well well-sm ">
                                    <div class="item">
                                        <?php if(!empty($data2->user->gambar) && is_file($imagepath.$data2->user->gambar.".jpg")): ?>
                                                <img src="<?php echo asset($imagepath.$data2->user->gambar.".jpg"); ?>" alt="user image" class="online" />
                                        <?php else: ?>
                                                <img src="<?php echo asset($imagepath."user.jpg"); ?>" alt="user image" class="online" />
                                        <?php endif; ?>
                                        <p class="message">
                                          <span class="name">
                                            <?php $date = new Date($data2->created_at); ?>
                                            <?php if($data2->id_user == $iduser): ?>
                                                <a data-toggle="modal" data-id="<?php echo e($data2->id); ?>" id="btnmodalhapus" href="#modalhapus"><small class="text-muted pull-right">&nbsp <i class="fa fa-trash"></i> &nbsp</small></a>
                                                <small class="text-muted pull-right">&nbsp | &nbsp</small>
                                                <a data-toggle="modal" data-id="<?php echo e($data2->id); ?>" data-content="<?php echo e($data2->content); ?>" id="btnmodalubah" href="#modalubah"><small class="text-muted pull-right">&nbsp <i class="fa fa-pencil"></i> &nbsp</small></a>
                                                <small class="text-muted pull-right">&nbsp | &nbsp</small>
                                            <?php endif; ?>
                                            <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> <?php echo e($date->format('j F Y, H:i')); ?> &nbsp</small>
                                            <?php echo e($data2->user->name); ?>

                                          </span>
                                          <?php echo $data2->content; ?>

                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <?php if($datas2->count() > 3): ?>
                            <hr style="margin-top: 10px;" />
                        <?php endif; ?>
                        <?php echo e(Form::model($datas2,array('route' => array('admins.'.$kelas2.'.store'),'method' => 'post','data-toggle' => 'validator','role' => 'form'))); ?>

                            <input type="text" name="id_laporan" value="<?php echo e($data->id); ?>" hidden>
                            <input type="text" name="route" value="<?php echo e(Request::path()); ?>" hidden>
                            <input type="text" name="no_ba" value="<?php echo e($data->no_ba); ?>" hidden>
                            <div class="input-group">
                                <input class="form-control" name="content" placeholder="Tuliskan pesan...." required="true" data-minlength="5">
                                <div class="input-group-btn">
                                  <button type="submit" class="btn btn-primary"><i class="fa fa-send"></i></button>
                                </div>
                          </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
            <div class="tab-pane" id="tab_revisi">
                <?php if(!empty($datahistories) && count($datahistories) > 0 ): ?>
                    <?php $__currentLoopData = $datahistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datahistory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="well well-sm">
                            <?php 
                                  $user = App\User::find($datahistory->user_id);
                                  $cuprimer = App\Cuprimer::find($user->cu);
                                  $date = new Date($datahistory->created_at); 
                              ?>
                            <i class="fa fa-caret-right text-muted"></i><b> <?php echo e($user->name); ?> 
                            <?php if($user->cu > 0): ?>
                                [<?php echo e($cuprimer->name); ?>]
                            <?php else: ?>
                                [BKCU]
                            <?php endif; ?>
                            </b> telah mengubah nilai 
                            <b>
                            <?php
                                switch($datahistory->key){
                                    case "l_biasa":
                                        echo "Anggota Lelaki Biasa";
                                        break;
                                    case "l_lbiasa":
                                        echo "Anggota Lelaki Luar Biasa";
                                        break;
                                    case "p_biasa":
                                        echo "Anggota Perempuan Biasa";
                                        break;
                                    case "p_lbiasa":
                                        echo "Anggota Perempuan Luar Biasa";
                                        break;
                                }
                            ?>
                            </b>   
                            dari <b><?php echo e(number_format($datahistory->old_value,"0",",",".")); ?></b> menjadi <b><?php echo e(number_format($datahistory->new_value,"0",",",".")); ?></b> pada <small class="text-muted"><?php echo e($date->format('d F')); ?> - <?php echo e($date->format('H:i')); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <?php else: ?>
                    <div class="well well-sm">
                        Tidak terdapat revisi.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!--content-->
</section>
<div class="modal fade" id="modalubah" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <?php echo e(Form::open(array('route' => array('admins.'.$kelas2.'.update',$kelas2), 'method' => 'put','data-toggle' => 'validator','role' => 'form'))); ?>

    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-light-blue-active color-palette">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title "><i class="fa fa-pencil"></i> Ubah Diskusi</h4>
            </div>
            <div class="modal-body">
                <input type="text" name="id" value="" id="modalubah_id" hidden>
                <input type="text" name="route" value="<?php echo e(Request::path()); ?>" hidden>
                <input type="text" name="no_ba" value="<?php echo e($data->no_ba); ?>" hidden>
                <div class="form-group">
                    <h4>Mengubah diskusi</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                        <?php echo e(Form::text('content',null,array('class' => 'form-control','id'=>'modalubah_content',
                        'placeholder' => 'Silahkan masukkan diskusi','autocomplete'=>'off','required','data-minlength'=>'5'))); ?>

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" id="modalbutton"><i class="fa fa-save"></i> Simpan</button>
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Batal</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
    <?php echo e(Form::close()); ?>

</div>
<div class="modal fade" id="modalhapus" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <?php echo e(Form::model($datas2,array('route' => array('admins.'.$kelas2.'.destroy',$kelas2), 'method' => 'delete'))); ?>

    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-red-active color-palette">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-trash fa-fw"></i> Hapus Diskusi</h4>
            </div>
            <div class="modal-body">
                <h4 style="font-size: 16px" id="modalhapus_detail">Hapus Diskusi</h4>
                <input type="text" name="id" value="" id="modalhapus_id" hidden>
                <input type="text" name="route" value="<?php echo e(Request::path()); ?>" hidden>
                <input type="text" name="no_ba" value="<?php echo e($data->no_ba); ?>" hidden>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-danger" id="modalbutton"><i class="fa fa-trash fa-fw"></i> Hapus</button>
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times fa-fw"></i> Batal</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
    <?php echo e(Form::close()); ?>

</div>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
    <script type="text/javascript">
        <?php if(!empty($datas2)): ?>
            <?php if($datas2->count() > 3): ?>
                $('#chat-box').slimScroll({
                    height: '50vh'
                });
            <?php endif; ?>    
        <?php endif; ?>
        $(function(){
            // bind change event to select
            $('#dynamic_select2').on('change', function () {
                var url = $(this).val(); // get selected value
                if (url) { // require a URL
                    window.location.href = url; // redirect
                }
                return false;
            });
        });
        // function hapusdiskusi(){
        //     var id = $(this).data('id');
        //      $('#modalhapus').modal({show:true});
        //      $('#modalhapus_judul').text('Hapus Diskusi Laporan CU');
        //      $('#modalhapus_detail').text('Hapus Diskusi Laporan CU');
        //      $('#modalhapus_id').attr('value',id);
        // }
        $(document).on("click", "#btnmodalhapus", function () {
             var id = $(this).data('id');
             $('#modalhapus_id').attr('value',id);
        });
        $(document).on("click", "#btnmodalubah", function () {
             var id = $(this).data('id');
             var content = $(this).data('content');
             $('#modalubah_id').attr('value',id);
             $('#modalubah_content').attr('value',content);
        });     
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>