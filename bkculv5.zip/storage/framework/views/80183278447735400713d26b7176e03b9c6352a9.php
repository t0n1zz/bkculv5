<?php
$title = "Kelola Saran atau Kritik";
$kelas = "saran"
?>


<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('admins._components.datatable_CSS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- header -->
<section class="content-header">
    <h1>
        <i class="fa fa-paper-plane-o"></i> <?php echo e($title); ?>

        <small>Mengelola Data Saran atau Kritik</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><i class="fa fa-paper-plane-o"></i> <?php echo e($title); ?></li>
    </ol>
</section>
<!-- /header -->
<section class="content">
    <!-- Alert -->
    <?php echo $__env->make('admins._layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /Alert -->
    <!--content-->
    <div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#tab_saran" data-toggle="tab">Saran Atau Kritik</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade in active" id="tab_saran">
                <div class="input-group tabletools">
                    <div class="input-group-addon"><i class="fa fa-search"></i></div>
                    <input type="text" id="searchtext" class="form-control" placeholder="Kata kunci pencarian..." autofocus>
                </div>
                <table class="table table-hover" id="dataTables-example" width="100%">
                    <thead class="bg-light-blue-active color-palette">
                    <tr >
                        <th data-sortable="false">#</th>
                        <th hidden></th>
                        <th>Nama </th>
                        <th>Saran dan Kritik</th>
                        <th>Tanggal</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($datas as $data): ?>
                        <tr>
                            <td class="bg-aqua disabled color-palette"></td>
                            <td hidden><?php echo e($data->id); ?></td>
                            <?php if(!empty($data->name)): ?>
                                <td class="warptext"><?php echo e($data->name); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>
                            <?php if(!empty($data->content)): ?>
                                <td class="warptext"><?php echo e($data->content); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>

                            <?php if(!empty($data->created_at )): ?>
                                <?php $date = new Date($data->created_at); ?>
                                <td><i hidden="true"><?php echo e($data->created_at); ?></i> <?php echo e($date->format('d/n/Y')); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--content-->
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('admins._components.datatable_JS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="text/javascript" src="<?php echo e(URL::asset('admin/datatable.js')); ?>"></script>
    <script>
        new $.fn.dataTable.Buttons(table,{
            buttons: [
                <?php if (Auth::check() && Auth::user()->can('destroy.'.$kelas.'_destroy')): ?>
                {
                    text: '<i class="fa fa-trash"></i> <u>H</u>apus',
                    key: {
                        altKey: true,
                        key: 'h'
                    },
                    action: function(){
                        var id = $.map(table.rows({ selected:true }).data(),function(item){
                            return item[1];
                        });
                        if(id != ""){
                            if(id != "1"){
                                $('#modalhapus').modal({show:true});
                                $('#modalhapus_id').attr('value',id);
                                $('#modalhapus_judul').text('Hapus Admin');
                                $('#modalhapus_detail').text('Yakin menghapus saran ini?');
                            }
                        }else{
                            $('#modalwarning').modal({show:true});
                        }
                    }
                }
                <?php endif; ?>
            ]
        });
        table.buttons( 0, null ).container().prependTo(
                table.table().container()
        );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>