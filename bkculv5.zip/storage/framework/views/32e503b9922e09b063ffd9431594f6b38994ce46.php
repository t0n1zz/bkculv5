<?php
$imagepath ='images_staf';
$kelas ='staf';
$file_max = ini_get('upload_max_filesize');
$file_max_str_leng = strlen($file_max);
$file_max_meassure_unit = substr($file_max,$file_max_str_leng - 1,1);
$file_max_meassure_unit = $file_max_meassure_unit == 'K' ? 'kb' : ($file_max_meassure_unit == 'M' ? 'mb' : ($file_max_meassure_unit == 'G' ? 'gb' : 'unidades'));
$file_max = substr($file_max,0,$file_max_str_leng - 1);
$file_max = intval($file_max);
?>
<!-- Alert -->
<?php echo $__env->make('admins._layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /Alert -->
<!-- content -->
<div class="box box-primary">
    <div class="box-body">
        <div class="row">
            <!--nama-->
            <div class="col-lg-6">
                <div class="form-group">
                    <h4>No. Identitas</h4>
                    <div class="input-group">
                        <span class="input-group-addon">0-9</span>
                        <?php echo e(Form::text('noid',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan nomor identitas',
                            'required','data-error' => 'Nomor identitas wajib di isi',
                            'autocomplete'=>'off'))); ?>

                    </div>
                    <div class="help-block with-errors"></div>
                    <?php echo $errors->first('name', '<p class="text-warning">:message</p>'); ?>

                </div>
                <div class="form-group">
                    <h4>Nama</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                        <?php echo e(Form::text('name',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan nama staff',
                            'required','data-error' => 'Nama staf wajib diisi',
                            'autocomplete'=>'off'))); ?>

                    </div>
                    <div class="help-block with-errors"></div>
                    <?php echo $errors->first('name', '<p class="text-warning">:message</p>'); ?>

                </div>
                <div class="row" id="pilihan" style="display: none;">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <h4>Kategori Baru</h4>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-font"></i></span>
                                <?php echo e(Form::text('kategori_baru',null,array('class' => 'form-control',
                                    'placeholder' => 'Silahkan masukkan kategori baru',
                                    'autocomplete'=>'off','maxlength' => '50'))); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <h4>Gender</h4>
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-list"></i></div>
                        <select class="form-control" name="kelamin">
                            <option selected disabled>Silahkan pilih jenis kelamin</option>
                            <option value="Pria"
                            <?php if(!empty($data)): ?>
                                <?php if($data->kelamin == "Pria"): ?>
                                    <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                    >Pria</option>
                            <option value="Wanita"
                            <?php if(!empty($staff)): ?>
                                <?php if($staff->kelamin == "Wanita"): ?>
                                    <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                    >Wanita</option>
                        </select>
                    </div>
                    <?php echo e($errors->first('kelamin', '<p class="text-warning">:message</p>')); ?>

                </div>
                <div class="form-group">
                    <h4>Tempat & Tanggal Lahir</h4>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-font"></i></span>
                                <?php echo e(Form::text('tempat_lahir',null,array('class' => 'form-control', 'placeholder' => 'Tempat'))); ?>

                                <?php echo e($errors->first('tempat_lahir', '<p class="text-warning">:message</p>')); ?>

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                <?php
                                if(!empty($data->tanggal_lahir)){
                                    $timestamp = strtotime($data->tanggal_lahir);
                                    $tanggal = date('d/m/Y',$timestamp);
                                }
                                ?>
                                <input type="text" name="bergabung" value="<?php if(!empty($tanggal)): ?><?php echo e($tanggal); ?><?php endif; ?>" class="form-control"
                                       data-inputmask="'alias': 'date'" placeholder="dd/mm/yyyy" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <h4>Agama</h4>
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-list"></i></div>
                        <select class="form-control" name="agama">
                            <option selected disabled>Silahkan pilih agama</option>
                            <option value="Khatolik"
                            <?php if(!empty($data)): ?>
                                <?php if($data->agama == "Khatolik"): ?>
                                    <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                            >Khatolik</option>
                            <option value="Protestan"
                            <?php if(!empty($data)): ?>
                                <?php if($data->agama == "Protestan"): ?>
                                    <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                            >Protestan</option>
                            <option value="Kong Hu Cu"
                            <?php if(!empty($data)): ?>
                                <?php if($data->agama == "Kong Hu Cu"): ?>
                                    <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                            >Kong Hu Cu</option>
                            <option value="Buddha"
                            <?php if(!empty($data)): ?>
                                <?php if($data->agama == "Buddha"): ?>
                                    <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                            >Buddha</option>
                            <option value="Hindu"
                            <?php if(!empty($data)): ?>
                                <?php if($data->agama == "Hindu"): ?>
                                    <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                            >Hindu</option>
                            <option value="Islam"
                            <?php if(!empty($data)): ?>
                                <?php if($data->agama == "Islam"): ?>
                                    <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                            >Islam</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <h4>Status Pernikahan</h4>
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-list"></i></div>
                        <select class="form-control" name="status">
                            <option selected disabled>Silahkan pilih jenis status</option>
                            <option value="Menikah"
                            <?php if(!empty($data)): ?>
                                <?php if($data->status == "Menikah"): ?>
                                    <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                            >Menikah</option>
                            <option value="Belum Menikah"
                            <?php if(!empty($data)): ?>
                                <?php if($data->status == "Belum Menikah"): ?>
                                    <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                            >Belum Menikah</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <h4>Kontak</h4>
                    <?php echo e(Form::textarea('kontak',null,array('class' => 'form-control','rows' => '3'))); ?>

                </div>
            </div>
            <!--/nama-->
            <!--gambar-->
            <div class="col-lg-6">
                <div>
                    <h4>Foto</h4>
                    <div class="thumbnail" >
                        <?php if(!empty($data->gambar) && is_file($imagepath.$data->gambar."n.jpg")): ?>
                            <?php echo e(Html::image($imagepath.$data->gambar.'n.jpg', 'a picture', array('class' => 'img-responsive', 'id' => 'tampilgambar', 'width' => '200'))); ?>

                        <?php else: ?>
                            <?php echo e(Html::image('images/no_image.jpg', 'a picture', array('class' => 'img-responsive', 'id' => 'tampilgambar', 'width' => '200'))); ?>

                        <?php endif; ?>
                        <div class="caption">
                            <?php echo e(Form::file('gambar', array('onChange' => 'readURL(this)'))); ?>

                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <h4>Alamat</h4>
                    <?php echo e(Form::textarea('content',null,array('class' => 'form-control','rows' => '3'))); ?>

                </div>
            </div>

            <div class="col-sm-12"><hr/></div>
        </div>
    </div>
    <div class="box-footer with-border">
        <div class="form-group">
            <button type="submit" name="simpan" accesskey="s" class="btn btn-primary">
                <i class="fa fa-save"></i> <u>S</u>impan</button>
            <button type="submit" name="simpan2" accesskey="m" class="btn btn-primary">
                <i class="fa fa-save fa-fw"></i><i class="fa fa-plus"></i> Si<u>m</u>pan dan buat baru</button>
            <a href="<?php echo e(route('admins.'.$kelas.'.index')); ?>" name="batal" accesskey="b" class="btn btn-danger">
                <i class="fa fa-times"></i> <u>B</u>atal</a>
        </div>
    </div>
</div>