<?php
    $pengumumans = App\Pengumuman::orderBy('urutan','asc')->get();
    $currentpage = $_SERVER['REQUEST_URI'];
    $navberita = App\KategoriArtikel::whereNotIn('id',array(1,4,8))->get();
/*
    if (Auth::check()) {
        Auth::logout();
    }
*/
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><html lang="en" class="no-js"> <![endif]-->
<html lang="en">
<head>
    <title>Puskopdit BKCU Kalimantan</title>
    <link rel="shortcut icon" href="<?php echo e(asset('images/logo.png')); ?>">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="author" content="Laurensius">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="296017390598287" />

    <?php if(!empty($detail_artikel)): ?>
        <title>Puskopdit BKCU Kalimantan | <?php echo e($detail_artikel->judul); ?></title>
        <!-- Facebook Open Graph Meta Tags -->
        <meta property="og:title" content="<?php echo e($detail_artikel->judul); ?>" />
        <meta property="og:url" content="<?php echo e(Request::url()); ?>" />
        <meta property="og:image" content="<?php echo e(asset('images_artikel/'.$detail_artikel->gambar.'.jpg')); ?>" />
        <meta property="og:description" content="<?php echo e(str_limit(preg_replace('/(<.*?>)|(&.*?;)/', '', $detail_artikel->content),200)); ?>" />
    <?php elseif(!empty($artikels)): ?>
        <title>Puskopdit BKCU Kalimantan | Artikel</title>
        <meta name="description" content="
        Artikel yang berisi informasi dan berita seputar Puskopdit BKCU Kalimantan, Credit Union Primer
        dalam jaringan kami, dan mengenai Credit Union secara umum.
        ">
    <?php elseif($currentpage =="/kegiatan"): ?>
        <title>Puskopdit BKCU Kalimantan | Kegiatan</title>
        <meta name="description" content="
        Kegiatan yang diselenggarakan oleh Puskopdit BKCU .
        ">
    <?php elseif($currentpage =="/profil"): ?>
        <title>Puskopdit BKCU Kalimantan | Profil</title>
        <meta name="description" content="
        Sebuah gerakan Credit Union yang terdiri dari Credit Union di Nusantara yang memiliki
        kesamaan semangat dan jiwa dalam mensejahterakan masyarakat sekitar.
        ">
    <?php elseif($currentpage =="/pengurus"): ?>
        <title>Puskopdit BKCU Kalimantan | Pengurus</title>
        <meta name="description" content="
        Sebuah gerakan Credit Union yang terdiri dari Credit Union di Nusantara yang memiliki
        kesamaan semangat dan jiwa dalam mensejahterakan masyarakat sekitar.
        ">
    <?php elseif($currentpage =="/pengawas"): ?>
        <title>Puskopdit BKCU Kalimantan | Pengawas</title>
        <meta name="description" content="
        Sebuah gerakan Credit Union yang terdiri dari Credit Union di Nusantara yang memiliki
        kesamaan semangat dan jiwa dalam mensejahterakan masyarakat sekitar.
        ">
    <?php elseif($currentpage =="/manajemen"): ?>
        <title>Puskopdit BKCU Kalimantan | Manajemen</title>
        <meta name="description" content="
        Sebuah gerakan Credit Union yang terdiri dari Credit Union di Nusantara yang memiliki
        kesamaan semangat dan jiwa dalam mensejahterakan masyarakat sekitar.
        ">
    <?php else: ?>
        <title>Puskopdit BKCU Kalimantan | Home</title>
        <meta name="description" content="
        Sebuah gerakan Credit Union yang terdiri dari Credit Union di Nusantara yang memiliki
                            kesamaan semangat dan jiwa dalam mensejahterakan masyarakat sekitar.
        ">
    <?php endif; ?>

    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" >
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" >
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Raleway:400,300,700" >
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>" >
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main-dist.css')); ?>" >
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/owl.css')); ?>" >
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/secondary-dist.css')); ?>" >

    <?php echo $__env->yieldContent('css'); ?>
    <!--[if IE 8]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

    <script type="text/javascript" src="<?php echo e(URL::asset('js/main-dist.js')); ?>"></script>
    <?php echo $__env->yieldContent('map'); ?>
</head>
<body >
<div id="container" class="boxed-page">


    <?php echo $__env->make('_layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>

 
    <?php echo $__env->make('_layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!--modal photos-->
    <div class="modal fade" id="modalphotoshow">
        <div class="modal-body">
            <img class="pointer img-responsive center-block" src="" id="modalimage"/>
        </div>
    </div>
    <!--/modal photos-->
</div>



<!-- Go To Top Link -->
<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>


    
        
        
    



<?php echo $__env->yieldContent('javascript'); ?>
<script type="text/javascript" src="<?php echo e(URL::asset('js/script-dist.js')); ?>" async></script>
<script>
//    $(window).load(function () {
//        "use strict";
//        $('#loader').fadeOut();
//    })

    $(document).ready(function() {

        $('.marquee').marquee({
            pauseOnHover: false,
            //speed in milliseconds of the marquee
            duration: 20000,
            //gap in pixels between the tickers
            gap: 5,
            //time in milliseconds before the marquee will start animating
            delayBeforeStart: 0,
            //'left' or 'right'
            direction: 'left',
            //true or false - should the marquee be duplicated to show an effect of continues flow
            duplicated: true
        });

        //modal photo
        $('.modalphotos img').on('click',function(){
            $('#modalphotoshow').modal({
                show: true,
            })

            var myscr = this.src;
            $('#modalimage').attr('src',myscr);
            $('#modalimage').on('click',function(){
                $('#modalphotoshow').modal('hide')
            })
        });
    });
</script>
</body>
</html>