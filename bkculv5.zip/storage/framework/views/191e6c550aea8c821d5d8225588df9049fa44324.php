<?php $__env->startSection('content'); ?>
<!-- Page Title -->
<div class="page-banner" style="padding:40px 0; background: url(images/slide-02-bg.jpg) center #f9f9f9;">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Kegiatan</h2>
                <p>Kegiatan yang diselenggarakan bidang <strong>DIKLAT</strong></p>
            </div>
            <div class="col-md-6">
                <ul class="breadcrumbs">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li>Kegiatan</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- /Page Title -->
<div id="content">
<div class="container">
    <div class="page-content">
        
        <div class="row">
            <div class="col-md-12">
                <h4 class="classic-title"><span>Jadwal Diklat 2016</span></h4>
                <br/>
                <div class="table-responsive">
                    <table class="table table-stripped table-hover" id="dataTables-example">
                        <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Jenis Diklat</th>
                            <th>Wilayah</th>
                            <th>Tempat</th>
                            <th>Waktu</th>
                            <th>Sasaran Peserta</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if($kegiatans->isEmpty()): ?>
                            <tr>
                                <td colspan="6">Belum terdapat kegiatan</td>
                            </tr>
                        <?php else: ?>
                        <?php $__currentLoopData = $kegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <?php if(!empty($kegiatan->tanggal)): ?>
                                    <?php $date = new Date($kegiatan->tanggal); ?>
                                    <td><i hidden="true"><?php echo e($kegiatan->tanggal); ?></i> <?php echo e($date->format('l, j F Y')); ?></td>
                                <?php else: ?>
                                    <td>-</td>
                                <?php endif; ?>

                                <?php if(!empty($kegiatan->name)): ?>
                                    <td><?php echo e($kegiatan->name); ?></td>
                                <?php else: ?>
                                    <td>-</td>
                                <?php endif; ?>

                                <?php if(!empty($kegiatan->wilayah)): ?>
                                    <td><?php echo e($kegiatan->wilayah); ?></td>
                                <?php else: ?>
                                    <td>-</td>
                                <?php endif; ?>

                                <?php if(!empty($kegiatan->tempat)): ?>
                                    <td><?php echo e($kegiatan->tempat); ?></td>
                                <?php else: ?>
                                    <td>-</td>
                                <?php endif; ?>

                                <?php
                                $startTimeStamp = strtotime($kegiatan->tanggal);
                                $endTimeStamp = strtotime($kegiatan->tanggal2);
                                $timeDiff = abs($endTimeStamp - $startTimeStamp);
                                $numberDays = $timeDiff/86400;
                                $numberDays = intval($numberDays) + 1;
                                $realnumber = sprintf("%02s", $numberDays);
                                ?>
                                <td class="event-venue"><i hidden="true"><?php echo e($realnumber); ?></i> <?php echo e($numberDays); ?> Hari</td>

                                <?php if(!empty($kegiatan->sasaran)): ?>
                                    <td><?php echo e($kegiatan->sasaran); ?></td>
                                <?php else: ?>
                                    <td>-</td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <br/>
                <div class="call-action call-action-boxed call-action-style3 clearfix">
                    <!-- Call Action Button -->
                    <div class="button-side" style="margin-top:4px;">
                        <a href="https://drive.google.com/file/d/0B5-CAlY_YuBDaEcxMDM2blNYeGM/view?usp=sharing"
                           target="_blank" class="btn-system border-btn btn-medium">Dapatkan Katalog Diklat 2015</a>
                        <br/><br/>
                        <a href="https://drive.google.com/file/d/0B5-CAlY_YuBDY2Nuc1BxT1VxVU0/view?usp=sharing"
                           target="_blank" class="btn-system border-btn btn-medium">Dapatkan Katalog Diklat 2016</a>
                    </div>
                    <!-- Call Action Text -->
                    <h2 class="primary">Kami juga menyediakan <strong>Katalog Diklat</strong></h2>
                    <p>Katalog Diklat di buat untuk memberikan informasi dan pemahaman lebih mengenai Diklat yang diselenggarakan.</p>
                </div>
                <div class="hr1 margin-top"></div>
            </div>
        </div>
        
        
        
        
            
                
                
                    
                        
                            
                                
                                    
                                        {{--<?php--}}
                                        
                                        
                                        
                                        
                                            
                                            
                                                
                                                     
                                            
                                        
                                    
                                
                            
                        
                    
                
            
            
                
                
                    
                        
                           
                    
                    
                
            
        </div>
        
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>