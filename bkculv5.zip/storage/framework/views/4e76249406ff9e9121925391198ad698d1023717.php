<table class="table table-striped table-condensed">
	<?php $akses= "artikel_cu"; $logo= "fa-book"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst('artikel')); ?></h5></td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td class="table-center">&nbsp;</td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "kegiatan_cu"; $logo= "fa-calendar"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst('kegiatan')); ?></h5></td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td class="table-center">&nbsp;</td>
        <td class="table-center">&nbsp;</td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "cu_cu"; $logo= "fa-building-o"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst('cu')); ?></h5></td>
        <td class="table-center">&nbsp;</td>
        <td class="table-center">&nbsp;</td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_detail" value="1" type="checkbox" id="<?php echo e($akses); ?>_detail"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'detail')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-database"></i> Detail</label>
            </div>
        </td>
        <td class="table-center">&nbsp;</td>
    </tr>
	<?php $akses= "tpcu_cu"; $judulakses="tp cu"; $logo= "fa-building-o"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst($judulakses)); ?></h5></td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td class="table-center">&nbsp;</td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "perkembangancu_cu"; $judulakses="perkembangan cu"; $logo= "fa-building-o"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst($judulakses)); ?></h5></td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_detail" value="1" type="checkbox" id="<?php echo e($akses); ?>_detail"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'detail')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-database"></i> Detail</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "staf_cu"; $logo= "fa-sitemap"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst('Staf')); ?></h5></td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_detail" value="1" type="checkbox" id="<?php echo e($akses); ?>_detail"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'detail')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-database"></i> Detail</label>
            </div>
        </td>
        <td class="table-center"><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
</table>