<?php $__env->startSection('content'); ?>
<!-- Page Title -->
<div class="page-banner" style="padding:40px 0; background: url(images/slide-02-bg.jpg) center #f9f9f9;">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Pelayanan Puskopdit BKCU Kalimantan</h2>
                <p>Pelayanan yang ditawarkan meliputi Bidang Keuangan, Bidang JALINAN dan Non Keuangan</p>
            </div>
            <div class="col-md-6">
                <ul class="breadcrumbs">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li>Pelayanan Puskopdit BCKU Kalimantan</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- /Page Title -->
<div id="content">
    <div class="container">
        <?php $i=1;$pos=""; ?>
        <?php foreach($pelayanans as $pelayanan): ?>
            <?php if($i % 2 == 0): ?>
                <?php $pos =2; ?>
            <?php elseif($i % 3 == 0): ?>
                <?php $pos =1; ?>
            <?php elseif($i % 2 == 1): ?>
                <?php $pos =1; ?>
            <?php endif; ?>

            <?php if($pos == 1): ?>
                <div class="big-title text-center" data-animation="fadeInDown" data-animation-delay="01">
                    <h1><?php echo e($pelayanan->name); ?></h1>
                    <hr/>
                </div>
                <div class="row" id="<?php echo e($pelayanan->id); ?>" data-animation="fadeInDown" data-animation-delay="01">
                    <div class="col-sm-6">
                        <?php echo $pelayanan->content; ?>

                    </div>
                    <div class="col-sm-6">
                        <?php if(!empty($pelayanan->gambar) && is_file("images_artikel/{$pelayanan->gambar}")): ?>
                            <?php echo e(Html::image('images_artikel/'.$pelayanan->gambar, $pelayanan->judul, array(
                                'class' => 'img-responsive img-thumbnail shadow','width' => '700px'))); ?>

                        <?php endif; ?>
                    </div>
                </div>
                    <div class="hr1" style="margin-bottom:40px;"></div>
            <?php elseif($pos ==2): ?>
                <div class="big-title text-center" data-animation="fadeInDown" data-animation-delay="01">
                    <h1><?php echo e($pelayanan->name); ?></h1>
                    <hr/>
                </div>
                <div class="row" id="<?php echo e($pelayanan->id); ?>" data-animation="fadeInDown" data-animation-delay="01">
                    <div class="col-sm-6">
                        <?php if(!empty($pelayanan->gambar) && is_file("images_artikel/{$pelayanan->gambar}")): ?>
                            <?php echo e(Html::image('images_artikel/'.$pelayanan->gambar, $pelayanan->judul, array(
                                'class' => 'img-responsive img-thumbnail shadow','width' => '700px'))); ?>

                        <?php endif; ?>
                    </div>
                    <div class="col-sm-6">
                        <?php echo $pelayanan->content; ?>

                    </div>
                </div>
                    <div class="hr1" style="margin-bottom:40px;"></div>
            <?php endif; ?>

            <?php  $i++; ?>
        <?php endforeach; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>