<?php $__env->startSection('content'); ?>
 <!-- Page Title -->
<div class="page-banner" style="padding:40px 0; background: url(images/slide-02-bg.jpg) center #f9f9f9;">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Credit Union <?php echo e($cudetail->name); ?></h2>
                <p>Credit Union Wilayah <?php echo e($cudetail->wilayahcuprimer->name); ?></p>
            </div>
            <div class="col-md-6">
                <ul class="breadcrumbs">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('cuprimer')); ?>">Credit Union</a></li>
                    <li>Credit Union <?php echo e($cudetail->name); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div id="content">
    <div class="container">
        <div class="page-content">
            <div class="big-title text-center">
                <?php if(!empty($cudetail->logo) && is_file("images_cu/{$cudetail->logo}")): ?>
                    <img src="<?php echo e(asset('images_cu/'.$cudetail->logo)); ?>" alt="<?php echo e($cudetail->name); ?>">
                <?php endif; ?>
                <h1>Selamat Datang Di <strong>Credit Union <?php echo e($cudetail->name); ?></strong></h1>
                <hr/>
                <p>
                    Kami merupakan CU yang memberikan pelayanan di wilayah <?php echo e($cudetail->wilayahcuprimer->name); ?>

                    <?php if(!empty($cudetail->bergabung)): ?>
                        <?php $datejoin = new Date($cudetail->bergabung); ?>
                        <?php echo e('sejak '.$datejoin->format('Y')); ?><br/>
                    <?php endif; ?>
                    <?php if(!empty($cudetail->tp)): ?>
                        <?php echo e('dan saat ini telah memiliki '.$cudetail->tp. ' tempat pelayanan/kantor pelayanan'); ?><br/>
                    <?php endif; ?>
                </p>
            </div>
            <?php if(!empty($cudetail->ultah)): ?>
                <?php
                $date = new Date($cudetail->ultah);
                $date2 = Date::now()->format('d-m');
                ?>
                <?php if($date->format('d-m') == $date2): ?>
                    <?php
                    $year1 = new Date($cudetail->ultah);
                    $year2 = Date::now()->format('Y');
                    $totalyear = $year2 - $year1->format('Y');
                    ?>
                    <div class="row">
                        <div class="col-md-12" data-animation="fadeInDown" data-animation-delay="01">
                            <div class="hr1 margin-top"></div>
                            <div class="call-action call-action-boxed call-action-style1 clearfix">
                                <div class="button-side" style="margin-top:4px;">
                                    <a href="<?php echo e(asset('images/birthday-card.jpg')); ?>"
                                       title="Selamat Ulang Tahun Ke <?php echo e($totalyear); ?> untuk Credit Union <?php echo e($cudetail->name); ?>

                                               Semoga Semakin Maju dan Terus Berkarya" target="_blank"
                                        class="btn-system border-btn btn-medium lightbox">Happy Birthday!!</a></div>
                                <h2 class="primary">Hari ini Credit Union <?php echo e($cudetail->name); ?> berulang tahun yang ke <strong><?php echo e($totalyear); ?></strong></h2>
                                <p>Kami seluruh jajaran Pengurus, Pengawas, Komite dan Manajemen Puskopdit BKCU Kalimantan mengucapkan
                                    <br/>
                                    Selamat Ulang Tahun Ke <?php echo e($totalyear); ?> untuk Credit Union <?php echo e($cudetail->name); ?> Semoga semakin bertumbuh
                                    dan berkembang bersama anggota serta semakin unggul dalam
                                    memberdayakan dan mensejahterakan masyarakat dengan semangat dan jiwa Credit Union </p>
                            </div>
                        </div>
                    </div>
                    <div class="hr1" style="margin-bottom:50px;"></div>
                <?php endif; ?>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-7">
                    <h4 class="classic-title"><span>Informasi Umum</span></h4>
                    <p>
                        <?php if(!empty($cudetail->badan_hukum)): ?>
                            <strong>No. Badan Hukum: </strong><?php echo e($cudetail->badan_hukum); ?><br/>
                        <?php endif; ?>
                        <?php if(!empty($cudetail->ultah)): ?>
                            <?php $date = new Date($cudetail->ultah); ?>
                            <strong>Tanggal Berdiri: </strong><?php echo e($date->format('j F Y')); ?><br/>
                        <?php endif; ?>
                        <?php if(!empty($cudetail->bergabung)): ?>
                            <?php $datejoin = new Date($cudetail->bergabung); ?>
                            <strong>Tanggal Bergabung: </strong><?php echo e($datejoin->format('j F Y')); ?><br/>
                        <?php endif; ?>
                        <?php if(!empty($cudetail->tp)): ?>
                            <strong>Jumlah Tempat Pelayanan / Kantor Pelayanan: </strong><?php echo e($cudetail->tp); ?><br/>
                        <?php endif; ?>
                        <br/>
                        <?php if(!empty($cudetail->telp)): ?>
                            <strong>No. Telepon: </strong><?php echo e($cudetail->telp); ?><br/>
                        <?php endif; ?>
                        <?php if(!empty($cudetail->hp)): ?>
                            <strong>No. Handphone: </strong><?php echo e($cudetail->hp); ?><br/>
                        <?php endif; ?>
                        <?php if(!empty($cudetail->email)): ?>
                            <strong>Email: </strong><a target="_blank" href="mailto:<?php echo e($cudetail->email); ?>"><?php echo e($cudetail->email); ?></a><br/>
                        <?php endif; ?>
                        <?php if(!empty($cudetail->website)): ?>
                            <strong>Website: </strong><a target="_blank" href="http://<?php echo e($cudetail->website); ?>"><?php echo e($cudetail->website); ?></a><br/>
                        <?php endif; ?>
                        <br/>
                        <?php if(!empty($cudetail->pos)): ?>
                            <strong>Kode Pos: </strong><?php echo e($cudetail->pos); ?><br/>
                        <?php endif; ?>
                        <?php if(!empty($cudetail->alamat)): ?>
                            <strong>Alamat: </strong><br/>
                            <?php echo e($cudetail->alamat); ?>

                        <?php endif; ?>

                    </p>
                </div>
                <div class="col-md-5 portfolio-item">
                    <div class="portfolio-thumb">
                        <?php $imagepath = 'images_cu/';?>
                        <?php if(!empty($cudetail->gambar) && is_file($imagepath.$cudetail->gambar.".jpg")): ?>
                            <a class="lightbox" title="<?php echo e($cudetail->name); ?>" href="<?php echo e(asset($imagepath.$cudetail->gambar.".jpg")); ?>">
                            <div class="thumb-overlay"><i class="fa fa-arrows-alt"></i></div>
                                <?php echo e(Html::image($imagepath.$cudetail->gambar.'.jpg',$cudetail->name,
                                    array('class' => 'img-responsive '))); ?>

                            </a>
                        <?php else: ?>
                        <a class="lightbox" title="<?php echo e($cudetail->name); ?>" href="<?php echo e(asset('images/image-cu.jpg')); ?>">
                            <div class="thumb-overlay"><i class="fa fa-arrows-alt"></i></div>
                            <?php echo e(Html::image('images/image-cu.jpg', $cudetail->name, array(
                                'class' => 'img-responsive'))); ?>

                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="hr1" style="margin-bottom:50px;"></div>
            <?php if(!empty($cudetail->deskripsi)): ?>
                <div class="big-title text-center" data-animation="fadeInDown" data-animation-delay="01">
                    <h1>Deskripsi <strong>Credit Union <?php echo e($cudetail->name); ?></strong></h1>
                    <p>Deskripsi umum mengenai Credit Union <?php echo e($cudetail->name); ?></p>
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <?php echo e($cudetail->deskripsi); ?>

                    </div>
                </div>
                <div class="hr1" style="margin-bottom:50px;"></div>
            <?php endif; ?>
            <?php if(!$stafs->isEmpty()): ?>
                <div class="big-title text-center" data-animation="fadeInDown" data-animation-delay="01">
                    <h1>Pengurus, Pengawas dan Manajemen <strong>Credit Union <?php echo e($cudetail->name); ?></strong></h1>
                    <p>Daftar Pengurus, Pengawas dan Manajemen Credit Union <?php echo e($cudetail->name); ?></p>
                </div>
                <div class="hr1" style="margin-bottom:50px;"></div>
                <div class="row" data-animation="fadeInDown" data-animation-delay="01">
                    <div class="col-md-12 col-sm-12">
                        <div class="table-responsive" >
                            <table class="table table-stripped table-hover" id="dataTables-example">
                                <thead>
                                <tr>
                                    <th>Nama </th>
                                    <th>Jabatan</th>
                                    <th>Tingkat</th>
                                    <th>Foto</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $stafs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>

                                        <?php if(!empty($staff->name)): ?>
                                            <td><?php echo e($staff->name); ?></td>
                                        <?php else: ?>
                                            <td>-</td>
                                        <?php endif; ?>

                                        <?php if(!empty($staff->jabatan)): ?>
                                            <td><?php echo e($staff->jabatan); ?></td>
                                        <?php else: ?>
                                            <td><a>-</a></td>
                                        <?php endif; ?>

                                        <?php if(!empty($staff->tingkat)): ?>
                                            <?php if($staff->tingkat == 1 ): ?>
                                                <?php if($staff->periode1 > 0 && $staff->periode2 > 0): ?>
                                                    <td>Pengurus Periode <?php echo e($staff->periode1); ?> - <?php echo e($staff->periode2); ?></td>
                                                <?php else: ?>
                                                    <td></td>Pengurus</td>
                                                <?php endif; ?>
                                            <?php elseif($staff->tingkat == 2): ?>
                                                <?php if($staff->periode1 > 0 && $staff->periode2 > 0): ?>
                                                    <td>Pengawas Periode <?php echo e($staff->periode1); ?> - <?php echo e($staff->periode2); ?></td>
                                                <?php else: ?>
                                                    <td>Pengawas</td>
                                                <?php endif; ?>
                                            <?php elseif($staff->tingkat == 3): ?>
                                                <td>Manajemen</td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <td>-</td>
                                        <?php endif; ?>

                                        <?php if(!empty($staff->gambar) && is_file("images_cu/{$staff->gambar}")): ?>
                                            <td><?php echo e(Html::image('images_cu/'.$staff->gambar, 'a picture', array('class' => 'img-responsive',
			        	'id' => 'tampilgambar', 'width' => '50'))); ?></td>
                                        <?php else: ?>
                                            <?php if($staff->kelamin == "Wanita"): ?>
                                                <td><?php echo e(Html::image('images/no_image_woman.jpg', 'a picture', array('class' => 'img-responsive',
                                                'id' => 'tampilgambar', 'width' => '50'))); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e(Html::image('images/no_image_man.jpg', 'a picture', array('class' => 'img-responsive',
                                                'id' => 'tampilgambar', 'width' => '50'))); ?></td>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="hr1" style="margin-bottom:50px;"></div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>