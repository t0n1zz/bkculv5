<?php
$title="Ubah Staf";
$kelas="staf";
?>


<?php $__env->startSection('content'); ?>
        <!-- header -->
<section class="content-header">
    <h1>
        <i class="fa fa-pencil-square-o"></i> <?php echo e($title); ?>

        <small>Mengubah Staf</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(route('admins.'.$kelas.'.index')); ?>"><i class="fa fa-sitemap"></i> Kelola Staf</a></li>
        <li class="active"><i class="fa fa-pencil-square-o"></i> <?php echo e($title); ?></li>
    </ol>
</section>
<!-- /header -->
<!-- Main content -->
<section class="content">
    <?php echo e(Form::model($data,array('route' => array('admins.'.$kelas.'.update',$data->id),'method' => 'put', 'files' => true,
        'data-toggle' => 'validator','role' => 'form'))); ?>

    <?php echo $__env->make('admins.'.$kelas.'.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo e(Form::close()); ?>

</section>
<!-- /Main content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>