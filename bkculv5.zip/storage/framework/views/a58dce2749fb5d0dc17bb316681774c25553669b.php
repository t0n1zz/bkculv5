<?php
$cusidebars = App\Cuprimer::orderBy('name','asc')->get();
$cu = Auth::user()->getCU();
$iduser = Auth::user()->getId();
?>
<aside class="main-sidebar">
    <section class="sidebar">
        <ul class="sidebar-menu">
            <!-- Sidebar user panel -->
            <div class="user-panel">
                <?php
                    $gambar = Auth::user()->getGambar();
                    $imagepath = 'images_user/';
                ?>
                <?php if(!empty($gambar) && is_file($imagepath.$gambar.".jpg")): ?>
                    <div class="pull-left image">
                        <img src="<?php echo asset($imagepath.$gambar.".jpg"); ?>" class="img-circle" alt="User Image" />
                    </div>
                <?php else: ?>
                    <div class="pull-left image">
                        <img src="<?php echo asset($imagepath."user.jpg"); ?>" class="img-circle" alt="User Image" />
                    </div>
                <?php endif; ?>
                <div class="pull-left info">
                    <p><?php echo Auth::user()->getName(); ?></p>
                    <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                </div>
            </div>
            <!-- Sidebar user panel -->
            <li class="header">NAVIGASI UTAMA</li>
            <!-- dashboard -->
            <li <?php echo e(Request::is('admins') ? 'class=active' : ''); ?>>
                <a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard "></i> <span>Dashboard</span></a>
            </li>
            <!-- /dashboard -->
            <!-- pengumuman -->
            <?php if (Auth::check() && Auth::user()->can('view.pengumuman_view')): ?>
                <li <?php echo Request::is('admins/pengumuman') ? 'class="active""' : ''; ?>>

                    <a href="<?php echo route('admins.pengumuman.index'); ?>"><i class="fa fa-comments-o "></i> <span>Pengumuman</span></a>
                </li>
            <?php endif; ?>
            <!-- /pengumuman -->
            <!-- artikel -->
            <?php if (Auth::check() && Auth::user()->can('view.artikel_view|view.kategoriartikel_view|create.artikel_create')): ?>
                <li <?php echo Request::is('admins/artikel') || Request::is('admins/artikel*') || Request::is('admins/kategoriartikel') ? 'class="treeview active"' : 'treeview'; ?> >
                    <a href="#"><i class="fa fa-book"></i> <span>Artikel</span> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                    <ul <?php echo e(Request::is('admins/artikel*') ? 'class=treeview-menu menu open style=display:block;' : 'class=treeview-menu'); ?>>
                        <?php if (Auth::check() && Auth::user()->can('create.artikel_create')): ?>
                        <li <?php echo Request::is('admins/artikel/create') ? 'class="treeview active"' : ''; ?> >
                            <a  href="<?php echo e(route('admins.artikel.create')); ?>"><i class="fa fa-plus"></i> Tambah</a>
                        </li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->can('view.artikel_view|view.kategoriartikel_view')): ?>
                        <li <?php echo Request::is('admins/artikel') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo e(route('admins.artikel.index')); ?>"><i class="fa fa-circle-o"></i> Kelola</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <!-- /artikel -->
            <!-- kegiatan -->
            <?php if (Auth::check() && Auth::user()->can('view.kegiatan_view|create.kegiatan_create')): ?>
                <?php if($cu !=0): ?>
                    <li <?php echo Request::is('admins/kegiatan') ? 'class="active"' : ''; ?>>
                        <a href="<?php echo e(route('admins.kegiatan.index')); ?>"><i class="fa fa-suitcase"></i> <span>Kegiatan BKCU</span></a>
                    </li>
                <?php else: ?>
                <li <?php echo Request::is('admins/kegiatan') || Request::is('admins/kegiatan*') ? 'class="treeview active"' : 'treeview'; ?> >
                    <a href="#"><i class="fa fa-suitcase"></i> <span>Kegiatan</span> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                    <ul <?php echo e(Request::is('admins/kegiatan*') ? 'class=treeview-menu menu open style=display:block;' : 'class=treeview-menu'); ?>>
                        <?php if (Auth::check() && Auth::user()->can('create.kegiatan_create')): ?>
                        <li <?php echo Request::is('admins/kegiatan/create') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo e(route('admins.kegiatan.create')); ?>"><i class="fa fa-plus"></i> Tambah</a>
                        </li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->can('view.kegiatan_view')): ?>
                        <li <?php echo Request::is('admins/kegiatan') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo e(route('admins.kegiatan.index')); ?>"><i class="fa fa-circle-o"></i> Kelola</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
            <?php endif; ?>
            <!-- /kegiatan -->
            <!-- cuprimer -->
            <?php if (Auth::check() && Auth::user()->can('view.cuprimer_view|view.wilayahcuprimer_view|create.cuprimer_create')): ?>
                <?php if($cu !=0): ?>
                    <li <?php echo Request::is('admins/cuprimer*') ? 'class="active"' : ''; ?>>
                        <a href="<?php echo e(route('admins.cuprimer.detail',array($cu))); ?>"><i class="fa fa-building"></i> <span>Profil CU</span></a>
                    </li>
                <?php else: ?>
                <li <?php echo Request::is('admins/cuprimer') || Request::is('admins/cuprimer*') || Request::is('admins/wilayahcuprimer') ? 'class="treeview active"' : 'treeview'; ?> >
                    <a href="#"><i class="fa fa-building-o"></i> <span>CU</span> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                    <ul <?php echo e(Request::is('admins/cuprimer*') ? 'class=treeview-menu menu open style=display:block;' : 'class=treeview-menu'); ?>>
                        <?php if (Auth::check() && Auth::user()->can('create.cuprimer_create')): ?>
                        <li <?php echo Request::is('admins/cuprimer/create') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo e(route('admins.cuprimer.create')); ?>"><i class="fa fa-plus"></i> Tambah</a>
                        </li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->can('view.cuprimer_view|view.tpcu_view|view.wilayahcuprimer_view')): ?>
                        <li <?php echo Request::is('admins/cuprimer') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo e(route('admins.cuprimer.index')); ?>"><i class="fa fa-circle-o"></i> Kelola</a>
                        </li>
                        <?php endif; ?>
                    </ul>    
                </li>
                <?php endif; ?>
            <?php endif; ?>
            <!-- /cuprimer -->
            <!-- tpcu -->
            <?php if (Auth::check() && Auth::user()->can('view.tpcu_view|create.tpcu_create')): ?>
                <li <?php echo Request::is('admins/tpcu*') ? 'class="treeview active"' : 'treeview'; ?> >
                    <a href="#"><i class="fa fa-home"></i> <span>TP CU</span> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                    <ul <?php echo e(Request::is('admins/tpcu*') ? 'class=treeview-menu menu open style=display:block;' : 'class=treeview-menu'); ?>>
                        <?php if (Auth::check() && Auth::user()->can('create.tpcu_create')): ?>
                        <li <?php echo Request::is('admins/tpcu/create') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo e(route('admins.tpcu.create')); ?>"><i class="fa fa-plus"></i> Tambah</a>
                        </li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->can('view.tpcu_view')): ?>
                        <li <?php echo Request::is('admins/tpcu') || Request::is('admins/tpcu/index_cu*') ? 'class="treeview active"' : ''; ?> >
                            <a <?php if($cu == '0'): ?>
                                    href="<?php echo e(route('admins.tpcu.index')); ?>"
                                <?php elseif($cu > '0'): ?>
                                    href="<?php echo e(route('admins.tpcu.index_cu',array($cu))); ?>"
                                <?php endif; ?>
                            ><i class="fa fa-circle-o"></i> Kelola</a>
                        </li>
                        <?php endif; ?>
                    </ul>    
                </li>
            <?php endif; ?>
            <!-- /tpcu -->
            <!-- staf -->
            <?php if (Auth::check() && Auth::user()->can('view.staf_view|create.staf_create')): ?>
                <li <?php echo Request::is('admins/staf') || Request::is('admins/staf*') ? 'class="treeview active"' : 'treeview'; ?> >
                    <a href="#"><i class="fa fa-sitemap"></i> <span>Staf</span> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                    <ul <?php echo e(Request::is('admins/staf*') ? 'class=treeview-menu menu open style=display:block;' : 'class=treeview-menu'); ?>>
                        <?php if (Auth::check() && Auth::user()->can('create.staf_create')): ?>
                        <li <?php echo Request::is('admins/staf/create') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo e(route('admins.staf.create')); ?>"><i class="fa fa-plus"></i> Tambah</a>
                        </li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->can('view.staf_view')): ?>
                        <li <?php echo Request::is('admins/staf') ? 'class="treeview active"' : ''; ?> >
                            <a  <?php if($cu == '0'): ?>
                                    href="<?php echo e(route('admins.staf.index')); ?>"
                                <?php elseif($cu > '0'): ?>
                                    href="<?php echo e(route('admins.staf.index_cu',array($cu))); ?>"
                                <?php endif; ?>
                            ><i class="fa fa-circle-o"></i> Kelola</a>
                        </li>
                        <?php endif; ?>     
                    </ul>    
                </li>
            <?php endif; ?>
            <!-- /staf -->
            <!-- laporancu -->
            <?php if (Auth::check() && Auth::user()->can('view.laporancu_view|create.laporancu_create')): ?>
                <li <?php echo Request::is('admins/laporancu') || Request::is('admins/laporancu*') ? 'class="treeview active"' : 'treeview'; ?> >
                    <a href="#"><i class="fa fa-line-chart"></i> <span>Laporan CU</span> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                    <ul <?php echo e(Request::is('admins/laporancu*') ? 'class=treeview-menu menu open style=display:block;' : 'class=treeview-menu'); ?>>
                        <?php if (Auth::check() && Auth::user()->can('create.laporancu_create')): ?>
                        <li <?php echo Request::is('admins/laporancu/create') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo route('admins.laporancu.create'); ?>"><i class="fa fa-plus"></i> Tambah</a>
                        </li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->can('view.laporancu_view')): ?>
                        <li <?php echo Request::is('admins/laporancu') || Request::is('admins/laporancu/index_cu*') || Request::is('admins/laporancu/index_bkcu') || Request::is('admins/laporancu/index_periode*') ? 'class="treeview active"' : ''; ?> >
                            <a <?php if($cu == '0'): ?>)
                                    href="<?php echo e(route('admins.laporancu.index')); ?>"
                                <?php else: ?>
                                    href="<?php echo e(route('admins.laporancu.index_cu',array($cu))); ?>"
                                <?php endif; ?>
                            ><i class="fa fa-circle-o"></i> Kelola</a>
                        </li>
                        <?php endif; ?>        
                    </ul>    
                </li>
            <?php endif; ?>
            <!-- /laporancu -->
            <!-- download -->
            <?php if (Auth::check() && Auth::user()->can('view.download_view')): ?>
                <li <?php echo Request::is('admins/download') || Request::is('admins/download*') ? 'class="treeview active"' : 'treeview'; ?> >
                    <a href="#"><i class="fa fa-download"></i> <span>Download</span> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                    <ul <?php echo e(Request::is('admins/download*') ? 'class=treeview-menu menu open style=display:block;' : 'class=treeview-menu'); ?>>
                        <li <?php echo Request::is('admins/download/create') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo e(route('admins.download.create')); ?>"><span class="fa fa-plus"></span> Tambah</a>
                        </li>
                        <li <?php echo Request::is('admins/download') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo e(route('admins.download.index')); ?>"><i class="fa fa-circle-o"></i> Kelola</a>
                        </li>
                    </ul>
                </li>
            <?php endif; ?>
            <!-- /download -->
            <!-- admin -->
            <?php if (Auth::check() && Auth::user()->can('detail.admin_detail')): ?>
                <li <?php echo Request::is('admins/admin*') ? 'class="active"' : ''; ?>>
                    <a href="<?php echo e(route('admins.admin.detail',array($iduser))); ?>"><i class="fa fa-user-circle-o"></i> <span>Admin</span></a>
                </li>
            <?php endif; ?>
            <?php if (Auth::check() && Auth::user()->can('view.admin_view|create.admin_create')): ?>
                <li <?php echo Request::is('admins/admin') || Request::is('admins/admin*') ? 'class="active"' : ''; ?> >
                    <a href="#"><i class="fa fa-user-circle-o"></i> <span>Admin</span> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                    <ul <?php echo e(Request::is('admins/admin*') ? 'class=treeview-menu menu open style=display:block;' : 'class=treeview-menu'); ?>>
                        <?php if (Auth::check() && Auth::user()->can('create.admin_create')): ?>
                        <li <?php echo Request::is('admins/admin/create') ? 'class="treeview active"' : ''; ?> >
                            <a href="<?php echo e(route('admins.admin.create')); ?>"><span class="fa fa-plus"></span> Tambah</a>
                        </li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->can('view.admin_view')): ?>
                        <li <?php echo Request::is('admins/admin') ? 'class="treeview active"' : ''; ?> >
                            <a href="#" data-toggle="modal" data-target="#modalcheckpass"><i class="fa fa-circle-o"></i> Kelola</a>
                        </li>
                        <?php endif; ?>    
                    </ul>
                </li>
            <?php endif; ?>  
            <!-- /admin -->
            <li class="header">LAIN-LAIN</li>
            <!-- foto kegiatan -->
            <li>
                <a href="https://www.flickr.com/photos/127271987@N07/"
                   target="_blank"><i class="fa fa-picture-o"></i> <span>Foto Kegiatan</span></a>
            </li>
            <!-- /foto kegiatan -->
            <!-- statistik -->
            <?php if (Auth::check() && Auth::user()->can('view.statistikweb_view')): ?>
                <li <?php echo Request::is('admins/statistik') ? 'class="active"' : ''; ?>>
                    <a href="<?php echo e(route('statistik')); ?>"><i class="fa fa-road"></i> <span>Statistik Website</span></a>
                </li>
            <?php endif; ?>
            <!-- /statistik -->
            <!-- saran -->
            <?php if (Auth::check() && Auth::user()->can('view.saran_view')): ?>
                <li <?php echo Request::is('admins/saran') ? 'class="active"' : ''; ?>>
                    <a href="<?php echo route('admins.saran.index'); ?>"><i class="fa fa-paper-plane-o"></i> <span>Saran atau Kritik</span></a>
                </li>
            <?php endif; ?>
            <!-- /saran -->
        </ul>
    </section>
</aside>
