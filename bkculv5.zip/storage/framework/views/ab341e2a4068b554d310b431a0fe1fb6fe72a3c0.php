<?php if(Session::has('sucessmessage')): ?>
    <div class="alert alert-info alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-check"></i> Success!</h4>
        <?php echo e(Session::get('sucessmessage')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('message')): ?>
    <div class="alert alert-warning alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-warning"></i> Perhatian!</h4>
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>

<?php if($errors->has()): ?>
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-ban"></i> Oops terjadi kesalahan!</h4>
        <ul class="list-unstyled">
            <?php foreach($errors->all() as $error): ?>
                <li>- <?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(Session::has('errormessage')): ?>
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-ban"></i> Oops terjadi kesalahan!</h4>
        <?php echo e(Session::get('errormessage')); ?>

    </div>
<?php endif; ?>
