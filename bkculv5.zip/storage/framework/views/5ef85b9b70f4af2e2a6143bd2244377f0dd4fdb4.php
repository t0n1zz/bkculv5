<?php
$title="Tambah CU";
$kelas="cuprimer";
?>


<?php $__env->startSection('content'); ?>
<!-- header -->
<section class="content-header">
    <h1>
        <i class="fa fa-plus"></i> <?php echo e($title); ?>

        <small>Menambah CU Primer Baru</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(route('admins.'.$kelas.'.index')); ?>"><i class="fa fa-building"></i> Kelola CU Primer</a></li>
        <li class="active"><i class="fa fa-plus"></i> <?php echo e($title); ?></li>
    </ol>
</section>
<!-- /header -->
<section class="content">
    <?php echo e(Form::open(array('route' => array('admins.'.$kelas.'.store'),'files' => true,
    'data-toggle' => 'validator','role' => 'form'))); ?>

    <?php echo $__env->make('admins.'.$kelas.'.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo e(Form::close()); ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>