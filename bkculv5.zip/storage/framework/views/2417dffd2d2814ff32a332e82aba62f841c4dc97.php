<?php
$title="Tambah Perkembangan CU";
$kelas="perkembangancu";
?>


<?php $__env->startSection('content'); ?>
        <!-- header -->
<section class="content-header">
    <h1>
        <i class="fa fa-plus"></i> <?php echo e($title); ?>

        <small>Menambah Data Perkembangan</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(route('admins.'.$kelas.'.index')); ?>"><i class="fa fa-book"></i> Kelola Perkembangan CU</a></li>
        <li class="active"><i class="fa fa-plus"></i> <?php echo $title; ?></li>
    </ol>
</section>
<!-- /header -->
<!-- Main content -->
<section class="content">
    <?php echo Form::open(array('route' => array('admins.'.$kelas.'.store'), 'files' => true, 'data-toggle' => 'validator','role' => 'form')); ?>

    <?php if(Auth::check()) { $id = Auth::user()->getId();} ?>
    <?php echo $__env->make('admins.'.$kelas.'.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

</section>
<!-- /Main content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>