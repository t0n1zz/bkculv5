<?php
$title="Home";
?>


<?php $__env->startSection('content'); ?>
        <!-- Page Title -->
<div class="page-banner" style="padding:40px 0; background: url(images/slide-02-bg.jpg) center #f9f9f9;">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('cu.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-6">
                <ul class="breadcrumbs">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li>CU</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div id="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('cu.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>