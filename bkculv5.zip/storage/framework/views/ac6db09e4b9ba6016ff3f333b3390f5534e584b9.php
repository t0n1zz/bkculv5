<?php
$title="Tambah Kegiatan";
$kelas="kegiatan";
?>


<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/summernote/summernote.css')); ?>" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- header -->
<section class="content-header">
    <h1>
        <i class="fa fa-plus"></i> <?php echo e($title); ?>

        <small>Menambah Kegiatan Baru</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(route('admins.'.$kelas.'.index')); ?>"><i class="fa fa-calendar"></i> Kelola Kegiatan</a></li>
        <li class="active"><i class="fa fa-plus"></i> <?php echo e($title); ?></li>
    </ol>
</section>
<!-- /header -->
<!-- Main content -->
<section class="content">
	<?php echo e(Form::open(array('route' => array('admins.'.$kelas.'.store'), 'files' => true,
	    'data-toggle' => 'validator','role' => 'form'))); ?>

        <?php if(Auth::check()) { $id = Auth::user()->getId();} ?>
        <input type="text" name="penulis" value="<?php echo e($id); ?>" hidden>
		<?php echo $__env->make('admins.'.$kelas.'.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo e(Form::close()); ?>

</section>
<!-- /Main content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(URL::asset('plugins/inputmask/jquery.inputmask.bundle.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/validator.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('plugins/summernote/summernote.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('plugins/form.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>