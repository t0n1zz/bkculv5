<?php $__env->startSection('content'); ?>
<?php $imagepath = 'images_artikel/';?>
<!-- Page Title -->
<div class="page-banner" style="padding:40px 0; background: url(images/slide-02-bg.jpg) center #f9f9f9;">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2><?php echo e($detail_artikel->KategoriArtikel->name); ?></h2>
                <p>Menampilkan Artikel <strong><?php echo e($detail_artikel->judul); ?></strong></p>
            </div>
            <div class="col-md-6">
                <ul class="breadcrumbs">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('artikel',array(0))); ?>">Semua Berita</a></li>
                    <li><a href="<?php echo e(route('artikel',array($detail_artikel->kategori))); ?>"><?php echo e($detail_artikel->KategoriArtikel->name); ?></a></li>
                    <li><?php echo e(str_limit($detail_artikel->judul,30)); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page Title -->
<div id="content">
    <div class="container">
        <div class="row blog-post-page">
            <div class="col-md-12 blog-box">
                <div class="blog-post gallery-post">
                    <div class="post-head">
                        <?php if(!empty($detail_artikel->gambar) && is_file($imagepath.$detail_artikel->gambar.".jpg")): ?>
                            <?php echo e(Html::image($imagepath.$detail_artikel->gambar.'.jpg',$detail_artikel->judul,
                                array('class' => 'img-responsive '))); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-9 blog-box">
                <div class="blog-post gallery-post">
                    <div class="post-content" style="padding-left: 0px">
                        <h1><?php echo e($detail_artikel->judul); ?></h1>
                        <br/>
                        <ul class="post-meta">
                            <li><?php $date = new Date($detail_artikel->created_at); ?>
                                <i class="fa fa-fw fa-calendar"></i> <b><?php echo e($date->format('l, j F Y, H:i')); ?></b></li>
                            <?php if(!empty($detail_artikel->penulis)): ?>
                            <li><i class="fa fa-fw fa-user"></i> <b><?php echo e($detail_artikel->penulis); ?></b></li>
                            <?php endif; ?>
                        </ul>
                        <hr/>
                        <?php echo $detail_artikel->content; ?>

                        <div class="post-bottom clearfix">
                            <div class="post-share">
                                <span><b>Share This Post:</b></span>
                                <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(Request::url()); ?>"
                                   onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;">
                                    <i class="fa fa-facebook"></i></a>
                                <a class="twitter" href="https://twitter.com/share?url=<?php echo e(Request::url()); ?>&amp;text=<?php echo e($detail_artikel->judul); ?>&amp;hashtags=BKCU"
                                   onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;">
                                    <i class="fa fa-twitter"></i></a>
                                <a class="gplus" href="https://plus.google.com/share?url=<?php echo e(Request::url()); ?>"
                                   onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;">
                                    <i class="fa fa-google-plus"></i></a>
                                <a class="linkedin" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo e(Request::url()); ?>"
                                   onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;">
                                    <i class="fa fa-linkedin"></i></a>
                                <a class="mail" href="javascript:;" onclick="window.print()">
                                    <i class="fa fa-print"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 sidebar right-sidebar">
                <div class="widget widget-search">
                    <?php echo e(Form::open(array('route' => array('cari'),'method' => 'get'))); ?>

                        <input type="search" name="q" placeholder="Enter Keywords..." />
                        <button class="search-btn" type="submit"><i class="fa fa-search"></i></button>
                    <?php echo e(Form::close()); ?>

                </div>

                <div class="widget widget-categories">
                    <h4>Kategori <span class="head-line"></span></h4>
                    <ul>
                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('artikel',array($kategori->id))); ?>"><?php echo e($kategori->name); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>

                <div class="widget widget-popular-posts">
                    <h4>Artikel Terbaru</h4>
                    <ul>
                        <?php $__currentLoopData = $artikelbarus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikelbaru): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <li>
                                <div class="widget-thumb">
                                    <a href="<?php echo e(route('artikel_detail',array($artikelbaru->id))); ?>">
                                    <?php if(!empty($artikelbaru->gambar) && is_file($imagepath.$artikelbaru->gambar."n.jpg")): ?>
                                        <?php echo e(Html::image($imagepath.$artikelbaru->gambar.'n.jpg',$artikelbaru->judul,
                                            array('class' => 'img-responsive '))); ?>

                                    <?php else: ?>
                                        <?php echo e(Html::image('images/image-articlen.jpg', $artikelbaru->judul, array(
                                            'class' => 'img-responsive'))); ?>

                                    <?php endif; ?>
                                    </a>
                                </div>
                                <div class="widget-content">
                                    <h5><?php echo e(link_to_route('artikel_detail', $artikelbaru->judul, array($artikelbaru->id))); ?> </h5>
                                    <?php $date = new Date($artikelbaru->created_at); ?>
                                    <span><?php echo e($date->format('j F Y')); ?></span>
                                </div>
                                <div class="clearfix"></div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>