<?php $__env->startSection('content'); ?>
<!-- Page Title -->
<div class="page-banner" style="padding:40px 0; background: url(images/slide-02-bg.jpg) center #f9f9f9;">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Credit Union</h2>
                <p>Credit Union dalam jaringan Puskopdit BKCU Kalimantan</p>
            </div>
            <div class="col-md-6">
                <ul class="breadcrumbs">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li>Credit Union</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- /Page Title -->
<div id="content">
    <div class="container">
    <?php $imagepath = 'images_cu/';?>
    <?php $__currentLoopData = $jejarings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jejaring): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="row">
        <h4 class="classic-title"><span><?php echo e($jejaring->name); ?></span></h4>
        <?php $__currentLoopData = $jejaring->cuprimer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuprimer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-md-3">
                <a href="<?php echo e(route('cuprimer_detail',array($cuprimer->id))); ?>">
                    <div class="portfolio-item item">
                        <div class="portfolio-border">
                            <div class="portfolio-thumb ">
                                <?php if(!empty($cuprimer->gambar) && is_file($imagepath.$cuprimer->gambar."n.jpg")): ?>
                                    <a class="lightbox" data-lightbox-type="ajax" title="<?php echo e('CU '.$cuprimer->name); ?>" href="<?php echo e(asset($imagepath.$cuprimer->gambar.".jpg")); ?>">
                                        <div class="thumb-overlay"><i class="fa fa-arrows-alt"></i></div>
                                        <?php echo e(Html::image($imagepath.$cuprimer->gambar.'n.jpg', 'CU '.$cuprimer->name,
                                            array('class' => 'img-responsive '))); ?>

                                    </a>
                                <?php else: ?>
                                    <a class="lightbox" data-lightbox-type="ajax" title="<?php echo e('CU '.$cuprimer->name); ?>" href="<?php echo e(asset('images/image-cu.jpg')); ?>">
                                        <div class="thumb-overlay"><i class="fa fa-arrows-alt"></i></div>
                                        <?php echo e(Html::
                                        image('images/image-cu.jpg', $cuprimer->name, array(
                                            'class' => 'img-responsive'))); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                            <div class="portfolio-details">
                                <a href="<?php echo e(route('cuprimer_detail',array($cuprimer->id))); ?>">
                                    <?php if(!empty($cuprimer->name)): ?>
                                        <h4>CU <?php echo e($cuprimer->name); ?></h4>
                                    <?php endif; ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div><br/>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>