<div class="table-responsive">
<table class="table table-condensed">
    <?php $akses= "pengumuman"; $logo= "fa-comments-o"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette">
            <h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst($akses)); ?></h5>
        </td>
        <td>
            <div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td>
            <div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td>
            <div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td>
            <div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div> 
        </td>
        <td>
            <div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update_urutan" value="1" type="checkbox" id="<?php echo e($akses); ?>_update_urutan" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /><i class="fa fa-ellipsis-v"></i> Urutan</label>
            </div>
        </td>
    </tr>
    <?php $akses= "saran"; $logo= "fa-paper-plane-o"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst($akses)); ?></h5></td>
        <td>
            <div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td>
            <div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "artikel"; $logo= "fa-book"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td rowspan="2" class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst($akses)); ?></h5></td>
        <td>
            <div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td>
            <div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update_status" value="1" type="checkbox" id="<?php echo e($akses); ?>_update_status"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-check-square"></i> Status</label>
            </div>
        </td>
    </tr>
    <tr>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update_pilihan" value="1" type="checkbox" id="<?php echo e($akses); ?>_update_pilihan"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-dot-circle-o"></i> Pilihan</label>
            </div>
        </td>
    </tr>
    <?php $akses= "kategoriartikel"; $logo= "fa-book"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> Kategori Artikel</h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "kegiatan"; $logo= "fa-calendar"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst($akses)); ?></h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "kegiatandetail"; $logo= "fa-calendar"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> Kegiatan (Detail)</h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-user"></i> Peserta</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-calculator"></i> Biaya</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-edit"></i> Evaluasi</label>
            </div>
        </td>
    </tr>
    <?php $akses= "cu"; $logo= "fa-building-o"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> CU</h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "tpcu"; $logo= "fa-building-o"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> TP CU</h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "wilayahcu"; $logo= "fa-building-o"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> Wilayah CU</h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "perkembangancu"; $logo= "fa-line-chart"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> Laporan CU</h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_importexcel" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-upload"></i> Upload</label>
            </div>
        </td>
    </tr>
    <?php $akses= "perkembangancudetail"; $logo= "fa-line-chart"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> Laporan CU (Detail)</h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_importexcel" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-upload"></i> Upload</label>
            </div>
        </td>
    </tr>
    <?php $akses= "staf"; $logo= "fa-users"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst($akses)); ?></h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "stafdetail"; $logo= "fa-users"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> Staf (Detail)</h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_riwayat" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_riwayat')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-address-card-o"></i> Riwayat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_kegiatan" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_kegiatan')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-calendar"></i> Kegiatan</label>
            </div>
        </td>
    </tr>
    <?php $akses= "download"; $logo="fa-download"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst($akses)); ?></h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update" value="1" type="checkbox" id="<?php echo e($akses); ?>_update" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-pencil"></i> Ubah</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
    </tr>
    <?php $akses= "admin"; $logo="fa-user-circle-o"; ?>
    <tr id="<?php echo e($akses); ?>">
        <td rowspan="2" class="bg-light-blue-active color-palette"><h5 class="hakakses-title"><i class="fa <?php echo e($logo); ?> fa-fw"></i> <?php echo e(ucfirst($akses)); ?></h5></td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_index" value="1" type="checkbox" id="<?php echo e($akses); ?>_index" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_index')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-eye"></i> Lihat</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_create" value="1" type="checkbox" id="<?php echo e($akses); ?>_create" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_create')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-plus"></i> Tambah</label>
            </div>
        </td>
        
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_destroy" value="1" type="checkbox" id="<?php echo e($akses); ?>_destroy"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_destroy')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-trash"></i> Hapus</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update_password" value="1" type="checkbox" id="<?php echo e($akses); ?>_update_password" 
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'_update')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-key"></i> Password</label>
            </div>
        </td>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update_akses" value="1" type="checkbox" id="<?php echo e($akses); ?>_update_akses"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'detail')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-hand-paper-o"></i> Akses</label>
            </div>
        </td>
    </tr>
    <tr>
        <td><div class="checkbox">
                <label><input name="<?php echo e($akses); ?>_update_status" value="1" type="checkbox" id="<?php echo e($akses); ?>_update_status"
                    <?php if(!empty($data)): ?> <?php if($data->can($akses.'detail')): ?> <?php echo e('checked'); ?> <?php endif; ?> <?php endif; ?>
                    /> <i class="fa fa-check-square"></i> Status</label>
            </div>
        </td>
    </tr>
</table>
</div>



