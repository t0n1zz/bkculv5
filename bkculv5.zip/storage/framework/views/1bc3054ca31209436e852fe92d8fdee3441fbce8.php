<?php
$title="Ubah Data Perkembangan CU";
$kelas="perkembangancu";
?>


<?php $__env->startSection('content'); ?>
    <!-- header -->
    <section class="content-header">
        <h1>
            <i class="fa fa-pencil"></i> <?php echo e($title); ?>

            <small>Mengubah Data Perkembangan</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('admins.'.$kelas.'.index')); ?>"><i class="fa fa-book"></i> Kelola Perkembangan CU</a></li>
            <li class="active"><i class="fa fa-pencil-square-o"></i> <?php echo e($title); ?></li>
        </ol>
    </section>
    <!-- /header -->
    <!-- Main content -->
    <section class="content">
        <?php echo e(Form::model($data,array('route' => array('admins.'.$kelas.'.update',$data->id),'method' => 'put', 'files' => true,
            'data-toggle' => 'validator','role' => 'form'))); ?>

        <?php echo e(Form::text('penulis',null,array('hidden'))); ?>

        <?php echo $__env->make('admins.'.$kelas.'.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo e(Form::close()); ?>

    </section>
    <!-- /Main content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>