<div class="tab-pane fade" id="tab_provinsi">
    <table class="table table-hover" id="dataTables-provinsi" width="100%">
        <thead>
        <tr class="bg-light-blue-active color-palette">
            <th rowspan="2">#</th>
            <th rowspan="2">Nama Provinsi/Wilayah</th>
            <th colspan="5">Anggota</th>
            <th rowspan="2">Kekayaan (ASET)</th>
            <th rowspan="2">Aktiva LANCAR</th>
            <th rowspan="2">Simpanan Saham(SP+SW)</th>
            <th colspan="2">Simpanan Non Saham</th>
            <th rowspan="2">Hutang SPD</th>
            <th colspan="2">Piutang</th>
            <th colspan="2">Piutang Lalai</th>
            <th colspan="2">Rasio Piutang</th>
            <th rowspan="2">DCR</th>
            <th rowspan="2">DCU</th>
            <th colspan="2">Total</th>
            <th rowspan="2">SHU</th>
        </tr>
        <tr class="bg-light-blue-active color-palette">
            <th>Lelaki Biasa</th>
            <th>Lelaki L.Biasa</th>
            <th>Perempuan Biasa</th>
            <th>Perempuan L.Biasa</th>
            <th>Total</th>
            <th>Unggulan</th>
            <th>Harian & Deposito</th>
            <th>Beredar</th>
            <th>Bersih</th>
            <th> 1-12 Bulan</th>
            <th> > 12 Bulan</th>
            <th>Beredar</th>
            <th>Lalai</th>
            <th>Pendapatan</th>
            <th>Biaya</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $tot_l_biasa = 0;
        $tot_l_lbiasa = 0;
        $tot_p_biasa = 0;
        $tot_p_lbiasa = 0;
        $tot_anggota = 0;
        $tot_kekayaan = 0;
        $tot_aktivalancar = 0;
        $tot_simpanansaham = 0;
        $tot_nonsaham_unggulan = 0;
        $tot_nonsaham_harian = 0;
        $tot_hutangspd = 0;
        $tot_piutangberedar = 0;
        $tot_piutanglalai_1bulan = 0;
        $tot_piutanglalai_12bulan = 0;
        $tot_piutangbersih = 0;
        $tot_dcr = 0;
        $tot_dcu = 0;
        $tot_totalpendapatan = 0;
        $tot_totalbiaya = 0;
        $tot_shu = 0;

        foreach($wilayahcuprimers as $wilayahcuprimer){
            $wilayahs[$wilayahcuprimer->id] = array(
                    'id'=> $wilayahcuprimer->id,'nama'=> $wilayahcuprimer->name,'l_biasa' => 0.0,'l_lbiasa' => 0.0,'p_biasa' => 0.0,'p_lbiasa' => 0.0,'kekayaan' => 0.0,
                    'aktivalancar' => 0.0,'simpanansaham' => 0.0,'nonsaham_unggulan' => 0.0,'nonsaham_harian' => 0.0,
                    'hutangspd' => 0.0,'piutangberedar' => 0.0,'piutanglalai_1bulan' => 0.0,'piutanglalai_12bulan' => 0.0,
                    'dcr' => 0.0,'dcu' => 0.0,'totalpendapatan' => 0.0,'totalbiaya' => 0.0,'shu' => 0.0
            );
        }

        foreach($wilayahs as $wil){
            foreach($datas as $data){
                if($data->cuprimer->wilayah == $wil['id']){
                    $wilayahs[$data->cuprimer->wilayah]['l_biasa'] += $data->l_biasa;
                    $wilayahs[$data->cuprimer->wilayah]['l_lbiasa'] += $data->l_lbiasa;
                    $wilayahs[$data->cuprimer->wilayah]['p_biasa'] += $data->p_biasa;
                    $wilayahs[$data->cuprimer->wilayah]['p_lbiasa'] += $data->p_lbiasa;
                    $wilayahs[$data->cuprimer->wilayah]['kekayaan'] += $data->kekayaan;
                    $wilayahs[$data->cuprimer->wilayah]['aktivalancar'] += $data->aktivalancar;
                    $wilayahs[$data->cuprimer->wilayah]['simpanansaham'] += $data->simpanansaham;
                    $wilayahs[$data->cuprimer->wilayah]['nonsaham_unggulan'] += $data->nonsaham_unggulan;
                    $wilayahs[$data->cuprimer->wilayah]['nonsaham_harian'] += $data->nonsaham_harian;
                    $wilayahs[$data->cuprimer->wilayah]['hutangspd'] += $data->hutangspd;
                    $wilayahs[$data->cuprimer->wilayah]['piutangberedar'] += $data->piutangberedar;
                    $wilayahs[$data->cuprimer->wilayah]['piutanglalai_1bulan'] += $data->piutanglalai_1bulan;
                    $wilayahs[$data->cuprimer->wilayah]['piutanglalai_12bulan'] += $data->piutanglalai_12bulan;
                    $wilayahs[$data->cuprimer->wilayah]['dcr'] += $data->dcr;
                    $wilayahs[$data->cuprimer->wilayah]['dcu'] += $data->dcu;
                    $wilayahs[$data->cuprimer->wilayah]['totalpendapatan'] += $data->totalpendapatan;
                    $wilayahs[$data->cuprimer->wilayah]['totalbiaya'] += $data->totalbiaya;
                    $wilayahs[$data->cuprimer->wilayah]['shu'] += $data->shu;
                }
            };
        }

        ?>
        <?php foreach($wilayahs as $data): ?>
            <tr >
                <td></td>
                <td><?php echo e($data['nama']); ?></td>

                <?php $l_biasa = number_format($data['l_biasa'],"0",",","."); $tot_l_biasa += $data['l_biasa'];?>
                <td data-order="<?php echo e($data['l_biasa']); ?>"><?php echo e($l_biasa); ?></td>

                <?php $l_lbiasa = number_format($data['l_lbiasa'],"0",",",".");  $tot_l_lbiasa += $data['l_lbiasa'];?>
                <td data-order="<?php echo e($data['l_lbiasa']); ?>"><?php echo e($l_lbiasa); ?></td>

                <?php $p_biasa = number_format($data['p_biasa'],"0",",","."); $tot_p_biasa += $data['p_biasa'];?>
                <td data-order="<?php echo e($data['p_biasa']); ?>"><?php echo e($p_biasa); ?></td>

                <?php $p_lbiasa = number_format($data['p_lbiasa'],"0",",","."); $tot_p_lbiasa += $data['p_lbiasa'];?>
                <td data-order="<?php echo e($data['p_lbiasa']); ?>"><?php echo e($p_lbiasa); ?></td>

                <?php
                $total = $data['l_biasa'] + $data['l_lbiasa'] + $data['p_biasa'] + $data['p_lbiasa'];
                $total_num = number_format($total,"0",",",".");
                $tot_anggota += $total;
                ?>
                <td data-order="<?php echo e($total); ?>"><?php echo e($total_num); ?></td>

                <?php $kekayaan = number_format($data['kekayaan'],"0",",","."); $tot_kekayaan += $data['kekayaan'];?>
                <td data-order="<?php echo e($data['kekayaan']); ?>"><?php echo e($kekayaan); ?></td>

                <?php $aktivalancar = number_format($data['aktivalancar'],"0",",","."); $tot_aktivalancar += $data['aktivalancar'];?>
                <td data-order="<?php echo e($data['aktivalancar']); ?>"><?php echo e($aktivalancar); ?></td>

                <?php $simpanansaham = number_format($data['simpanansaham'],"0",",","."); $tot_simpanansaham += $data['simpanansaham'];?>
                <td data-order="<?php echo e($data['simpanansaham']); ?>"><?php echo e($simpanansaham); ?></td>

                <?php $nonsaham_unggulan = number_format($data['nonsaham_unggulan'],"0",",","."); $tot_nonsaham_unggulan += $data['nonsaham_unggulan'];?>
                <td data-order="<?php echo e($data['nonsaham_unggulan']); ?>"><?php echo e($nonsaham_unggulan); ?></td>

                <?php $nonsaham_harian = number_format($data['nonsaham_harian'],"0",",","."); $tot_nonsaham_harian += $data['nonsaham_harian'];?>
                <td data-order="<?php echo e($data['nonsaham_harian']); ?>"><?php echo e($nonsaham_harian); ?></td>

                <?php $hutangspd = number_format($data['hutangspd'],"0",",","."); $tot_hutangspd += $data['hutangspd'];?>
                <td data-order="<?php echo e($data['hutangspd']); ?>"><?php echo e($hutangspd); ?></td>

                <?php $piutangberedar = number_format($data['piutangberedar'],"0",",","."); $tot_piutangberedar += $data['piutangberedar'];?>
                <td data-order="<?php echo e($data['piutangberedar']); ?>"><?php echo e($piutangberedar); ?></td>

                <?php $piutanglalai_1bulan = number_format($data['piutanglalai_1bulan'],"0",",","."); $tot_piutanglalai_1bulan += $data['piutanglalai_1bulan'];?>
                <td data-order="<?php echo e($data['piutanglalai_1bulan']); ?>"><?php echo e($piutanglalai_1bulan); ?></td>

                <?php $piutanglalai_12bulan = number_format($data['piutanglalai_12bulan'],"0",",","."); $tot_piutanglalai_12bulan += $data['piutanglalai_12bulan'];?>
                <td data-order="<?php echo e($data['piutanglalai_12bulan']); ?>"><?php echo e($piutanglalai_12bulan); ?></td>

                <?php
                $piutangbersih = $data['piutangberedar'] - ($data['piutanglalai_1bulan'] + $data['piutanglalai_12bulan']);
                $piutangbersih_num = number_format($piutangbersih,"0",",",".");
                $tot_piutangbersih += $piutangbersih;
                ?>
                <td data-order="<?php echo e($piutangbersih); ?>"><?php echo e($piutangbersih_num); ?></td>

                <?php $rasio_beredar = number_format((($data['piutangberedar'] / $data['kekayaan'])*100),2); ?>
                <td data-order="<?php echo e($rasio_beredar); ?>"><?php echo e($rasio_beredar); ?> %</td>

                <?php $rasio_lalai = number_format(((($data['piutanglalai_1bulan'] + $data['piutanglalai_12bulan']) / $data['piutangberedar'])*100),2); ?>
                <td data-order="<?php echo e($rasio_lalai); ?>"><?php echo e($rasio_lalai); ?> %</td>

                <?php $dcr = number_format($data['dcr'],"0",",","."); $tot_dcr += $data['dcr'];?>
                <td data-order="<?php echo e($data['dcr']); ?>"><?php echo e($dcr); ?></td>

                <?php $dcu = number_format($data['dcu'],"0",",","."); $tot_dcu += $data['dcu'];?>
                <td data-order="<?php echo e($data['dcu']); ?>"><?php echo e($dcu); ?></td>

                <?php $totalpendapatan = number_format($data['totalpendapatan'],"0",",","."); $tot_totalpendapatan += $data['totalpendapatan'];?>
                <td data-order="<?php echo e($data['totalpendapatan']); ?>"><?php echo e($totalpendapatan); ?></td>

                <?php $totalbiaya = number_format($data['totalbiaya'],"0",",","."); $tot_totalbiaya += $data['totalbiaya'];?>
                <td data-order="<?php echo e($data['totalbiaya']); ?>"><?php echo e($totalbiaya); ?></td>

                <?php $shu = number_format($data['shu'],"0",",","."); $tot_shu += $data['shu'];?>
                <td data-order="<?php echo e($data['shu']); ?>"><?php echo e($shu); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
        <tr class="bg-lime-active color-palette">
            <th>TOTAL</th>
            <th></th>
            <th><?php echo e(number_format($tot_l_biasa,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_l_lbiasa,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_p_biasa,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_p_lbiasa,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_anggota,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_kekayaan,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_aktivalancar,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_simpanansaham,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_nonsaham_unggulan,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_nonsaham_harian,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_hutangspd,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_piutangberedar,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_piutanglalai_1bulan,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_piutanglalai_12bulan,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_piutangbersih,"0",",",".")); ?></th>
            <th>-</th>
            <th>-</th>
            <th><?php echo e(number_format($tot_dcr,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_dcu,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_totalpendapatan,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_totalbiaya,"0",",",".")); ?></th>
            <th><?php echo e(number_format($tot_shu,"0",",",".")); ?></th>
        </tr>
        </tfoot>
    </table>
</div>