<?php
$title="Ubah Password Admin";
$kelas="admin";
?>


<?php $__env->startSection('content'); ?>
        <!-- header -->
<section class="content-header">
    <h1>
        <i class="fa fa-pencil-square-o"></i> <?php echo e($title); ?>

        <small>Mengubah Password Admin</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(URL::to('admins')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(route('admins.'.$kelas.'.index')); ?>"><i class="fa fa-user"></i> Kelola Admin</a></li>
        <li class="active"><i class="fa fa-pencil-square-o"></i> <?php echo e($title); ?></li>
    </ol>
</section>
<!-- /header -->
<!-- Main content -->
<section class="content">
<?php echo e(Form::model($data,array('route' => array('admins.'.$kelas.'.update_password',$data->id), 'files' => true,
    'data-toggle' => 'validator','role' => 'form'))); ?>

    <!-- Alert -->
    <?php echo $__env->make('admins._layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /Alert -->
    <!-- content -->
    <div class="box box-primary">
        <div class="box-header with-border">
            <div class="form-group">
                <button type="submit" name="simpan" accesskey="s" class="btn btn-primary">
                    <i class="fa fa-save"></i> <u>S</u>impan</button>
                <a href="<?php echo e(route('admins.'.$kelas.'.index')); ?>" name="batal" accesskey="b" class="btn btn-danger">
                    <i class="fa fa-times"></i> <u>B</u>atal</a>
            </div>
        </div>
        <div class="box-body">
            <div class="row">
                <!--username-->
                <div class="col-lg-12">
                    <h4>Username</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                        <?php echo e(Form::text('username',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan username',
                            'autocomplete'=>'off','readonly'))); ?>

                        <?php echo e($errors->first('username', '<p class="text-warning">:message</p>')); ?>

                    </div>
                </div>
                <!--/username-->
                <!--password 1-->
                <div class="col-lg-6">
                    <h4>Password</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                        <?php echo e(Form::password('password',array('class' => 'form-control','placeholder' => 'Silahkan masukkan password admin'))); ?>

                        <?php echo e($errors->first('password', '<p class="text-warning">:message</p>')); ?>

                    </div>
                </div>
                <br/>
                <!--/password 1-->
                <!--password 2-->
                <div class="col-lg-6">
                    <h4>Konfirmasi Password</h4>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-font"></i></span>
                        <?php echo e(Form::password('password2',array('class' => 'form-control','placeholder' => 'Silahkan masukkan password admin sekali lagi'))); ?>

                        <?php echo e($errors->first('password2', '<p class="text-warning">:message</p>')); ?>

                    </div>
                </div>
                <!--/password 2-->
            </div>
        </div>
    </div>
<?php echo e(Form::close()); ?>

</section>
<!-- /Main content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>