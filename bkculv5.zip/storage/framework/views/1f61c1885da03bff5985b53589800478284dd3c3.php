<?php
$title="Dashboard";
$data = App\LaporanCu::orderBy('periode','ASC')->groupBy('periode')->get(['periode']);
$periodeiode = $data->groupBy('periode');
$cu = Auth::user()->getCU();
$iduser = Auth::user()->getId();
$date = Date::now()->format('d-m');
$query = "SELECT  id,name FROM cuprimer WHERE DATE_FORMAT(ultah, '%d-%m') = '$date' ";
$ultahcu = DB::select(DB::raw($query));


?>


<?php if (Auth::check() && Auth::user()->can('view.saran_view')): ?>
<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('admins._components.datatable_CSS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        <i class="fa fa-dashboard"></i> <b>Dashboard</b>
        <small>Panel Informasi</small>
    </h1>
    <ol class="breadcrumb">
        <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <!-- Alert -->
    <?php echo $__env->make('admins._layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Alert -->
    <!-- birthday -->
    <?php if(!empty($ultahcu)): ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-birthday-cake"></i> Selamat ulang tahun kepada
                <?php $__currentLoopData = $ultahcu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ultah): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php echo e('CU ' . $ultah->name); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </h4>
        </div>
    <?php endif; ?>
    <!-- birthday -->
    <!-- Small boxes (Stat box) -->
    <div class="row">
        <!-- pengumuman -->
        <?php if (Auth::check() && Auth::user()->can('view.pengumuman_view')): ?>
            <div class="col-xs-6 col-sm-3 col-md-2">
                <div class="small-box bg-aqua">
                    <?php $total_pengumuman = App\Pengumuman::count(); $route = route('admins.pengumuman.index'); ?>
                    <div class="inner">
                        <a href="<?php echo e($route); ?>" style="color:white">
                            <h3><?php echo e($total_pengumuman); ?></h3>
                            <p>Pengumuman</p>
                        </a>
                    </div>
                    <div class="icon">
                       <a href="<?php echo e($route); ?>" style="color: rgba(0, 0, 0, 0.15)">
                            <i class="fa fa-comments-o"></i>
                       </a>
                    </div>
                    <a href="<?php echo e($route); ?>"
                       class="small-box-footer">Lihat <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        <?php endif; ?>
        <!-- /pengumuman -->
        <!-- artikel -->
        <?php if (Auth::check() && Auth::user()->can('view.artikel_view')): ?>
            <div class="col-xs-6 col-sm-3 col-md-2">
                <div class="small-box bg-green">
                    <?php $total_artikel = App\Artikel::count(); $route = route('admins.artikel.index');?>
                    <div class="inner">
                        <a href="<?php echo e($route); ?>" style="color:white">
                            <h3><?php echo e($total_artikel); ?></h3>
                            <p>Artikel</p>
                        </a>
                    </div>
                    <div class="icon">
                        <a href="<?php echo e($route); ?>" style="color: rgba(0, 0, 0, 0.15)">
                            <i class="fa fa-book"></i>
                        </a>
                    </div>
                    <a href="<?php echo e($route); ?>"
                       class="small-box-footer">Lihat <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        <?php endif; ?>
        <!-- /artikel -->
        <!-- kegiatan -->
        <?php if (Auth::check() && Auth::user()->can('view.kegiatan_view')): ?>
            <div class="col-xs-6 col-sm-3 col-md-2">
                <div class="small-box bg-red">
                    <?php $total_kegiatan = App\Kegiatan::count();$route = route('admins.kegiatan.index'); ?>
                    <div class="inner">
                        <a href="<?php echo e($route); ?>" style="color:white">
                            <h3><?php echo e($total_kegiatan); ?></h3>
                            <p>Kegiatan</p>
                        </a>
                    </div>
                    <div class="icon">
                        <a href="<?php echo e($route); ?>" style="color: rgba(0, 0, 0, 0.15)">
                            <i class="fa fa-suitcase"></i>
                        </a>
                    </div>
                    <a href="<?php echo e($route); ?>"
                       class="small-box-footer">Lihat <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        <?php endif; ?>
        <!-- /kegiatan -->
        <!-- cuprimer -->
        <?php if (Auth::check() && Auth::user()->can('view.cuprimer_view')): ?>
            <div class="col-xs-6 col-sm-3 col-md-2">
                <div class="small-box bg-yellow">
                    <?php
                      if($cu == '0'){
                        $total_cuprimer = App\Cuprimer::where('status','1')->count();
                        $route = route('admins.cuprimer.index');
                      }else{
                        $route = route('admins.cuprimer.detail',array($cu));
                      }
                    ?>
                    <div class="inner">
                        <a href="<?php echo e($route); ?>" style="color:white">
                          <?php if($cu == '0'): ?>
                            <h3><?php echo e($total_cuprimer); ?></h3>
                            <p>CU</p>
                          <?php else: ?>
                            <h3>&nbsp</h3>
                            <p>Profil CU</p>
                          <?php endif; ?>
                        </a>
                    </div>
                    <div class="icon">
                        <a href="<?php echo e($route); ?>" style="color: rgba(0, 0, 0, 0.15)">
                            <i class="fa fa-building"></i>
                        </a>
                    </div>
                    <a href="<?php echo e($route); ?>"
                       class="small-box-footer">Lihat <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        <?php endif; ?>
        <!-- /cuprimer -->
        <!-- tpcu -->
        <?php if (Auth::check() && Auth::user()->can('view.cuprimer_view')): ?>
            <div class="col-xs-6 col-sm-3 col-md-2">
                <div class="small-box bg-aqua">
                    <?php
                      if($cu == '0'){
                        $total_tp = App\TpCU::count();
                        $route = route('admins.tpcu.index');
                      }else{
                        $total_tp = App\TpCU::where('cu','=',$cu)->count();
                        $route = route('admins.tpcu.index_cu',array($cu));
                      }
                    ?>
                    <div class="inner">
                        <a href="<?php echo e($route); ?>" style="color:white">
                            <h3><?php echo e($total_tp); ?></h3>
                            <p>TP CU</p>
                        </a>
                    </div>
                    <div class="icon">
                        <a href="<?php echo e($route); ?>" style="color: rgba(0, 0, 0, 0.15)">
                            <i class="fa fa-home"></i>
                        </a>
                    </div>
                    <a href="<?php echo e($route); ?>"
                       class="small-box-footer">Lihat <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        <?php endif; ?>
        <!-- /tpcu -->
        <!-- laporancu -->
        <?php if (Auth::check() && Auth::user()->can('view.laporancu_view|view.laporancudetail_view')): ?>
            <div class="col-xs-6 col-sm-3 col-md-2">
                <div class="small-box bg-green">
                    <?php
                        if($cu != 0)
                            $total_laporan = App\LaporanCu::where('no_ba','=',$cu)->count();
                        else
                            $total_laporan = App\LaporanCu::count();
                        if(Auth::user()->can('view.laporancu_view') && $cu == '0'){
                            $route = route('admins.laporancu.index');
                        }elseif(Auth::user()->can('view.laporancu_view') && $cu != '0'){
                            $route = route('admins.laporancu.index_cu',array($cu));
                        }
                        ?>
                    <div class="inner">
                         <a href="<?php echo e($route); ?>" style="color:white">
                            <h3><?php echo e($total_laporan); ?></h3>
                            <p>Laporan CU</p>
                        </a>
                    </div>
                    <div class="icon">
                        <a href="<?php echo e($route); ?>" style="color: rgba(0, 0, 0, 0.15)">
                            <i class="fa fa-line-chart"></i>
                        </a>
                    </div>
                        <a href="<?php echo e($route); ?>"
                           class="small-box-footer">Lihat <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        <?php endif; ?>
        <!-- /laporancu -->
        <!-- staf -->
        <?php if (Auth::check() && Auth::user()->can('view.staf_view')): ?>
            <div class="col-xs-6 col-sm-3 col-md-2">
                <div class="small-box bg-red">
                    <?php
                        if($cu != 0)
                            $total_staff = App\Staf::with('cuprimer')->where('cu','=',$cu)->count();
                        else
                            $total_staff = App\Staf::count();

                        $route = route('admins.staf.index');
                        ?>
                    <div class="inner">
                        <a href="<?php echo e($route); ?>" style="color:white">
                            <h3><?php echo e($total_staff); ?></h3>
                            <p>Staf</p>
                        </a>
                    </div>
                    <div class="icon">
                        <a href="<?php echo e($route); ?>" style="color: rgba(0, 0, 0, 0.15)">
                            <i class="fa fa-sitemap"></i>
                        </a>
                    </div>
                    <a href="<?php echo e($route); ?>"
                       class="small-box-footer">Lihat <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        <?php endif; ?>
        <!-- /staf -->
        <!-- download -->
        <?php if (Auth::check() && Auth::user()->can('view.download_view')): ?>
            <div class="col-xs-6 col-sm-3 col-md-2">
                <div class="small-box bg-yellow">
                    <?php $total_download = App\Download::count(); $route = route('admins.download.index');?>
                    <div class="inner">
                        <a href="<?php echo e($route); ?>" style="color:white">
                            <h3><?php echo e($total_download); ?></h3>
                            <p>Download</p>
                        </a>
                    </div>
                    <div class="icon">
                        <a href="<?php echo e($route); ?>" style="color: rgba(0, 0, 0, 0.15)">
                            <i class="fa fa-download"></i>
                        </a>
                    </div>
                    <a href="<?php echo e($route); ?>"
                       class="small-box-footer">Lihat <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        <?php endif; ?>
        <!-- /download -->
        <!-- admin -->
        <?php if (Auth::check() && Auth::user()->can('view.admin_view|detail.admin_detail')): ?>
            <div class="col-xs-6 col-sm-3 col-md-2">
                <div class="small-box bg-aqua">
                    <?php
                      if($cu == '0'){
                        $total_admin = App\User::count();
                        $route = route('admins.admin.index');
                      }else{
                        $route = route('admins.admin.detail',array($iduser));
                      }
                    ?>
                    <div class="inner">
                        <?php if (Auth::check() && Auth::user()->can('detail.admin_detail')): ?>
                            <a href="<?php echo e(route('admins.admin.detail',array($iduser))); ?>"  style="color:white">
                        <?php else: ?>
                             <a href="#" data-toggle="modal" data-target="#modalcheckpass" style="color:white">
                        <?php endif; ?>
                          <?php if($cu == '0'): ?>
                            <h3><?php echo e($total_admin); ?></h3>
                            <p>Admin</p>
                          <?php else: ?>
                            <h3>&nbsp</h3>
                            <p>Admin</p>
                          <?php endif; ?>
                        </a>
                    </div>
                    <div class="icon">
                        <?php if (Auth::check() && Auth::user()->can('detail.admin_detail')): ?>
                            <a href="<?php echo e(route('admins.admin.detail',array($iduser))); ?>" style="color: rgba(0, 0, 0, 0.15)">
                        <?php else: ?>
                            <a href="#" data-toggle="modal" data-target="#modalcheckpass" style="color: rgba(0, 0, 0, 0.15)">
                        <?php endif; ?>
                            <i class="fa fa-user-circle-o"></i>
                        </a>
                    </div>
                    <?php if (Auth::check() && Auth::user()->can('detail.admin_detail')): ?>
                        <a href="<?php echo e(route('admins.admin.detail',array($iduser))); ?>" class="small-box-footer">
                    <?php else: ?>
                        <a href="#" data-toggle="modal" data-target="#modalcheckpass" class="small-box-footer">
                    <?php endif; ?>
                       Lihat <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        <?php endif; ?>
        <!-- /admin -->
    </div>
    <!-- /Small boxes (Stat box) -->
    <!-- Main content -->
    <?php if(Auth::user()->can('view.laporanbkcu_view') || Auth::user()->can('view.laporancu_view')): ?>
        <?php echo $__env->make('admins._components.laporancu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-lg-5">
            <?php if (Auth::check() && Auth::user()->can('view.statistikweb_view')): ?>
            <!--statistik website-->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Statistik Pengunjung Website</h3>
                    <div class="box-tools pull-right">
                        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <?php
                    $tabel = "stat_pengunjung";
                    $tanggal = date("Ymd");
                    $pengunjung = DB::table($tabel)
                            ->where('tanggal',$tanggal)
                            ->groupBy('ip')
                            ->count();
                    $totalpengunjung = DB::table($tabel)
                            ->count();
                    $bataswaktu       = time() - 300;
                    $pengunjungonline = DB::table($tabel)
                            ->where('online','>',$bataswaktu)
                            ->count();
                    $tanggal_hariini  = date('d-m-Y');
                    ?>
                    <h4 style="text-align: center;" ><b>Pengunjung Hari Ini</b></h4>
                    <h4 style="text-align: center;" ><?php echo e(Date::now()->format('l , j F Y ')); ?></h4>
                    <h3 style="text-align: center;" ><b><?php echo e($pengunjung); ?></b> orang</h3>
                    <hr />
                    <dl class="dl-horizontal">
                        <dt><b style="font-size: 13px" >Total Pengunjung : </b></dt>
                        <dd><b style="font-size: 13px" ><?php echo e($totalpengunjung); ?> orang</b></dd>
                        <dt><b style="font-size: 13px" >Pengunjung Online : </b></dt>
                        <dd><b style="font-size: 13px" ><?php echo e($pengunjungonline); ?> orang</b></dd>
                        <dt><b style="font-size: 13px" >Reset : </b></dt>
                        <dd><b style="font-size: 13px" > 5 September 2014 </b></dd>
                    </dl>
                </div>
                <div class="box-footer clearfix">
                    <a href="<?php echo e(route('statistik')); ?>" class="btn btn-primary btn-block">
                        <div>
                            <span class="pull-left"><b>Detail</b></span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <!--/statistik website-->
            <?php endif; ?>
        </div>
        <div class="col-lg-7">
            <?php if (Auth::check() && Auth::user()->can('view.saran_view')): ?>
            <!-- saran -->
            <div class="box box-primary ">
                <div class="box-header with-border">
                    <h3 class="box-title">Saran Atau Kritik</h3>
                    <div class="box-tools pull-right">
                        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <?php $sarans = App\Saran::orderBy('created_at','desc')->take(10)->get(); ?>
                    <table class="table table-hover" id="dataTables-saran" width="100%">
                        <thead class="bg-light-blue-active color-palette">
                            <tr >
                                <th hidden></th>
                                <th>Nama </th>
                                <th>Saran dan Kritik</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td hidden></td>
                                    <?php if(!empty($data->name)): ?>
                                        <td class="warptext"><?php echo e($data->name); ?></td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>
                                    <?php if(!empty($data->content)): ?>
                                        <td class="warptext"><?php echo e($data->content); ?></td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>

                                    <?php if(!empty($data->created_at )): ?>
                                        <?php $date = new Date($data->created_at); ?>
                                        <td><i hidden="true"><?php echo e($data->created_at); ?></i> <?php echo e($date->format('d/n/Y')); ?></td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <a href="<?php echo e(route('admins.saran.index')); ?>" class="btn btn-primary btn-block">
                        <div>
                            <span class="pull-left"><b>Detail</b></span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
                <!-- /saran -->
            </div>
            <!-- /saran -->
            <?php endif; ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php if (Auth::check() && Auth::user()->can('view.saran_view')): ?>
<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('admins._components.datatable_JS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="text/javascript">
        var table = $('#dataTables-saran').DataTable({
            dom: 't',
            select: true,
            scrollY: '40vh',
            scrollX: true,
            autoWidth: true,
            scrollCollapse : true,
            paging : false,
            stateSave : false,
            order : [],
            buttons: [],
            language: {
                buttons : {},
                select:{
                    rows:{
                        _: "",
                        0: "",
                        1: ""
                    }
                },
                "sProcessing":   "Sedang proses...",
                "sLengthMenu":   "Tampilan _MENU_ entri",
                "sZeroRecords":  "Tidak ditemukan data yang sesuai",
                "sInfo":         "Tampilan _START_ sampai _END_ dari _TOTAL_ entri",
                "sInfoEmpty":    "Tampilan 0 hingga 0 dari 0 entri",
                "sInfoFiltered": "(disaring dari _MAX_ entri keseluruhan)",
                "sInfoPostFix":  "",
            }
        });

        table.on( 'order.dt search.dt', function () {
            table.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
                cell.innerHTML = i+1;
            } );
        } ).draw();
    </script>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('admins._layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>