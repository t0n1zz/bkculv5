<?php $__env->startSection('content'); ?>
        <!-- Page Title -->
<div class="page-banner" style="padding:40px 0; background: url(images/slide-02-bg.jpg) center #f9f9f9;">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Pengawas Puskopdit BKCU Kalimantan</h2>
            </div>
            <div class="col-md-6">
                <ul class="breadcrumbs">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li>Pengawas Puskopdit BCKU Kalimantan</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- /Page Title -->
<?php $imagepath = 'images_staf/';?>
<div id="content">
    <div class="container">
        <div class="big-title text-center" data-animation="fadeInDown" data-animation-delay="01">
            <h1>Pengawas <strong>Puskopdit BKCU Kalimantan</strong></h1>
            <p>Periode 2015 - 2017</p>
        </div>
        <div class="row" data-animation="fadeInDown" data-animation-delay="01">
            <?php $__currentLoopData = $pengawases2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengawas): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="team-member">
                        <div class="member-photo">
                            <?php if(!empty($pengawas->gambar) && is_file($imagepath.$pengawas->gambar.".jpg")): ?>
                                <?php echo e(Html::image($imagepath.$pengawas->gambar.'.jpg',$pengawas->name)); ?>

                            <?php else: ?>
                                <?php echo e(Html::image('images/no_image_man.jpg', $pengawas->name)); ?>

                            <?php endif; ?>
                        </div>
                        <div class="member-info">
                            <strong><?php echo e($pengawas->name); ?></strong>
                            <br/>
                            <?php echo e($pengawas->jabatan); ?>

                            <hr/>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
        <div class="hr1" style="margin-bottom:50px;"></div>
        <div class="big-title text-center" data-animation="fadeInDown" data-animation-delay="01">
            <h1>Pengawas <strong>Puskopdit BKCU Kalimantan</strong></h1>
            <p>Periode 2012 - 2014</p>
        </div>
        <div class="row" data-animation="fadeInDown" data-animation-delay="01">
            <?php $__currentLoopData = $pengawases1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengawas): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="team-member">
                        <div class="member-photo">
                            <?php if(!empty($pengawas->gambar) && is_file($imagepath.$pengawas->gambar.".jpg")): ?>
                                <?php echo e(Html::image($imagepath.$pengawas->gambar.'.jpg',$pengawas->name)); ?>

                            <?php else: ?>
                                <?php echo e(Html::image('images/no_image_man.jpg', $pengawas->name)); ?>

                            <?php endif; ?>
                        </div>
                        <div class="member-info">
                            <strong><?php echo e($pengawas->name); ?></strong>
                            <br/>
                            <?php echo e($pengawas->jabatan); ?>

                            <hr/>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>