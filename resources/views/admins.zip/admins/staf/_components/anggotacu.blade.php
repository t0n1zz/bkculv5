<div class="row">
    <div class="col-sm-12">
        <button type="button" class="btn btn-default btn-block" id="cutambah" onclick="func_cutambah()">Punya keanggotaan di CU</button>
    </div>
</div> 