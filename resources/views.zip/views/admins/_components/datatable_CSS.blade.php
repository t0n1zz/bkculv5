<link rel="stylesheet" type="text/css" href="{{asset('plugins/dataTables/dataTables.bootstrap.min.css')}}" >
<link rel="stylesheet" type="text/css" href="{{asset('plugins/dataTables/extension/KeyTable/css/keyTable.bootstrap.min.css')}}" >
<link rel="stylesheet" type="text/css" href="{{asset('plugins/dataTables/extension/Select/css/select.dataTables.min.css')}}" >
<link rel="stylesheet" type="text/css" href="{{asset('plugins/dataTables/extension/Select/css/select.bootstrap.min.css')}}" >
<link rel="stylesheet" type="text/css" href="{{asset('plugins/dataTables/extension/Buttons/css/buttons.dataTables.min.css')}}" >
<link rel="stylesheet" type="text/css" href="{{asset('plugins/dataTables/extension/Buttons/css/buttons.bootstrap.min.css')}}" >
