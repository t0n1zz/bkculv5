@extends('_layouts.layout')

@section('content')
<div id="content">
    <div class="container">
        <div class="page-content">
            <div class="error-page">
                <h1>404</h1>
                <h3><b>Oops!</b> Telah Terjadi Kesalahan</h3>
                <p>Maaf, telah terjadi kesalahan, Halaman yang anda tuju tidak ada atau mengalami kerusakan</p>
                <div class="text-center"><a href="http://www.puskopditbkcukalimantan.org"
                                            class="btn-system btn-small">Kembali Ke Home</a></div>
            </div>
        </div>
    </div>
</div>
@stop
